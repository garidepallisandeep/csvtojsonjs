#!/bin/bash
# Create debug log directory
mkdir -p out
export RED=$(tput setaf 1)
export GREEN=$(tput setaf 2)
export NORMAL=$(tput sgr0) # No Color
export NC='\033[0m'
export OUTPUT_DIR="$(cd $(dirname $0); pwd -L)/../../out"

function print_label() {
    printf "%-${SYSINFO_TITLE_WIDTH}s %s\n" "$1:" "$2"
}

function print_meta() {
  cat << EOF
  $1: $2
  Date & Time: $(date)
  CSP Detected: $CSP
EOF
}
function print_time() {
  print_label "Date & Time " "$(date)"
}

function print_banner() {
  echo "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*"
}

# function print_banner() {
#      printf -- "-%.0s" $(seq 1 130)
#      echo ""
# }

function print_header() {
    local len=$((${#1}+2))
    printf "\n+"
    printf -- "-%.0s" $(seq 1 $len)
    printf "+\n| $1 |\n+"
    printf -- "-%.0s" $(seq 1 $len)
    printf "+\n\n"
}

function print_title() {
cat << "EOF"
   _____ _____  _____     ____        _                         _ _                _____                                  _
  / ____|  __ \|  __ \   / __ \      | |                       | (_)              / ____|                                (_)
 | |    | |  | | |__) | | |  | |_ __ | |__   ___   __ _ _ __ __| |_ _ __   __ _  | |     ___  _ __ ___  _ __   __ _ _ __  _  ___  _ __
 | |    | |  | |  ___/  | |  | | '_ \| '_ \ / _ \ / _` | '__/ _` | | '_ \ / _` | | |    / _ \| '_ ` _ \| '_ \ / _` | '_ \| |/ _ \| '_ \
 | |____| |__| | |      | |__| | | | | |_) | (_) | (_| | | | (_| | | | | | (_| | | |___| (_) | | | | | | |_) | (_| | | | | | (_) | | | |
  \_____|_____/|_|       \____/|_| |_|_.__/ \___/ \__,_|_|  \__,_|_|_| |_|\__, |  \_____\___/|_| |_| |_| .__/ \__,_|_| |_|_|\___/|_| |_|
                                                                           __/ |                       | |
                                                                          |___/                        |_|
EOF
}

function fetch_parameters_aws()
{
  paramfile=${1}
  export region=$(cat ${paramfile} | jq -r .required.region)
  export nw_endpoints=$(cat ${paramfile} | jq -r .required.networkEndpointsFile)
  export CDPcontrolplaneregion=$(cat ${paramfile} | jq -r .required.CDPcontrolplaneregion)
  export bucket_name=$(cat ${paramfile} | jq -r .iam.bucket_name)
  export cross_account_role=$(cat ${paramfile} | jq -r .iam.cross_account_role)
  export datalake_admin_role=$(cat ${paramfile} | jq -r .iam.datalake_admin_role)
  export idbroker_role=$(cat ${paramfile} | jq -r .iam.idbroker_role)
  export log_role=$(cat ${paramfile} | jq -r .iam.log_role)
  export ranger_audit_role=$(cat ${paramfile} | jq -r .iam.ranger_audit_role)
  export cdp_log_policy=$(cat ${paramfile} | jq -r .iam.cdp_log_policy)
  export cdp_backup_policy=$(cat ${paramfile} | jq -r .iam.cdp_backup_policy)
  export cdp_ranger_audit_s3_policy=$(cat ${paramfile} | jq -r .iam.cdp_ranger_audit_s3_policy)
  export cdp_datalake_admin_s3_policy=$(cat ${paramfile} | jq -r .iam.cdp_datalake_admin_s3_policy)
  export cdp_bucket_access_policy=$(cat ${paramfile} | jq -r .iam.cdp_bucket_access_policy)
  export datalake_backup_policy=$(cat ${paramfile} | jq -r .iam.datalake_backup_policy)
  export datalake_restore_policy=$(cat ${paramfile} | jq -r .iam.datalake_restore_policy)
  export cross_account_minimum_policy=$(cat ${paramfile} | jq -r .iam.cross_account_minimum_policy)
  export storage_base_location=$(cat ${paramfile} | jq -r .iam.storage_base_location)
  export backup_location_base=$(cat ${paramfile} | jq -r .iam.backup_location_base)
  export log_location_base=$(cat ${paramfile} | jq -r .iam.log_location_base)

  export vpc_count=$(cat ${paramfile} | jq -r .quota.vpc_count)
  export subnets_count=$(cat ${paramfile} | jq -r .quota.subnets_count)
  export internet_gateways_count=$(cat ${paramfile} | jq -r .quota.internet_gateways_count)
  export nat_gateways_coount=$(cat ${paramfile} | jq -r .quota.nat_gateways_coount)
  export elastic_ips_count=$(cat ${paramfile} | jq -r .quota.elastic_ips_count)
  export elastic_loadbalancers_count=$(cat ${paramfile} | jq -r .quota.elastic_loadbalancers_count)
  export rds_db_instances_count=$(cat ${paramfile} | jq -r .quota.rds_db_instances_count)  
  export eks_clusters_count=$(cat ${paramfile} | jq -r .quota.eks_clusters_count)
  export ec2_instances_count=$(cat ${paramfile} | jq -r .quota.ec2_instances_count)  
}
function fetch_parameters_azure()
{
     paramfile=${1}
     export region=$(cat ${paramfile} | jq -r .required.region)
     export nw_endpoints=$(cat ${paramfile} | jq -r .required.networkEndpointsFile)
     export CDPcontrolplaneregion=$(cat ${paramfile} | jq -r .required.CDPcontrolplaneregion)
}

function fetch_parameters_gcp()
{
    service_account=$(cat config/gcp_config.json |grep -i "serviceaccount" | cut -d'"' -f4)
    vpc=$(cat config/gcp_config.json |grep -i "vpc" | cut -d'"' -f4)
    project_id=$(cat config/gcp_config.json |grep -i "project" | cut -d'"' -f4)
    region=$(cat config/gcp_config.json |grep -i "region" | cut -d'"' -f4)
    subnet=$(cat config/gcp_config.json |grep -i "subnet" | cut -d'"' -f4)
    user=$(cat config/gcp_config.json |grep -i "user" | cut -d'"' -f4)
    bucket=$(cat config/gcp_config.json |grep -i "bucket" | cut -d'"' -f4)
}

#############################################################
# Function : log
# Description : write log file.
#############################################################
# function log(){
#     SCRIPT_NAME=$(basename ${0})
#     MESSAGE=${1}
#     LOG_FILE="${LOG_DIRECTORY}/run_all_checks_$(date +%m-%d-%Y).log"
#     echo -e "$(date +"%r"): ${SCRIPT_NAME} :${MESSAGE}" >> ${LOG_FILE}
# }

function log(){
    local msg=$1
    local title=$2
    echo -e "[ $(date) ] [${title}]: ${msg}"
}

function state() {
    local msg=$1
    local flag=$2
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    NC='\033[0m' # No Color

    if [ "$flag" -eq 0 ]; then
        echo -e "[ $(date) ] [${GREEN} PASS ${NC}] $msg" >$(tty)
    elif [ "$flag" -eq 2 ]; then
        echo -e "[ $(date) ] [${YELLOW} WARN ${NC}] $msg" >$(tty)
    else
        echo -e "[ $(date) ] [${RED} FAIL ${NC}] $msg" >$(tty)
    fi
}

function print_fqdn() {
    print_label "FQDN" "$(hostname -f)"
}

#############################################################
# Function: run_setup
# Description : Function to create required directories(out & log)
#############################################################
function run_setup(){
    mkdir -p $(cd $(dirname $0); pwd -L)/output
    mkdir -p $(cd $(dirname $0); pwd -L)/logs
    export LOG_DIRECTORY="$(cd $(dirname $0); pwd -L)/logs"
    export OUTPUT_DIR="$(cd $(dirname $0); pwd -L)/output"
}

#############################################################
# Function: print_output
# Description : Function to print output in formatted manner
#############################################################
function print_output(){
  len=$#
  output=""
  for i in $(seq 1 1 $len)
  do
    output="${output}| %-45s"
  done
  printf "$output|\n" "$@"
}

#############################################################
# Function: clean_up
# Description : Clean up log and output files created.
#############################################################
function clean_up()
{
  rm -f ${LOG_DIRECTORY}/*$(date +%m-%d-%Y).log
  rm -f ${OUTPUT_DIR}/*$(date +%m-%d-%Y).output
}

#############################################################
# Function: check_https_url
# Description : Check HTTPS url with the returned HttpStatus code
#############################################################
check_https_url()
{
	StatusCode=$(curl $1 --insecure --connect-timeout 4 -s -o /dev/null -w "%{http_code}")
	if [ "$StatusCode" -ge 200 ] && [ "$StatusCode" -le 404 ] || [ "$StatusCode" -eq 200 ];
	then
    printf "| %-60s | %-30s |\n" "${1}" "${GREEN} REACHABLE ${NORMAL}"
	else
	  printf "| %-60s | %-30s |\n" "${1}" "${RED} NOT-REACHABLE ${NORMAL}"
    printf "| %-60s | %-30s |\n" "${1}" "${RED} NOT-REACHABLE ${NORMAL}" >> $OUTPUT_DIR/tmp_network_output
		overallstatus=1;
	fi;
}

#############################################################
# Function: check_nonhttp
# Description : Check TCP successful connection
#############################################################
check_nonhttp()
{
  #Usage  nc -v -w 2 https://test.v2.ccm.eu-1.cdp.cloudera.com 443
	check=`nc -v -w 2 $1 $2 | grep succeeded | wc -l`
	if [ $check -eq 1 ];then
	  printf "| %-60s | %-30s |\n" "${1}" "${GREEN} REACHABLE ${NORMAL}"
  else
    printf "| %-60s | %-30s |\n" "${1}" "${RED} NOT-REACHABLE ${NORMAL}"
    overallstatus=1;
  fi;
}

#############################################################
# Calculate the conflict of two CIDR range.
# Usage: overlap $CIDR1 $CIDR2
# return value: 0 for no conflict; 1 for conflict;
#############################################################
read_range () {
    IFS=/ read ip mask <<<"$1"
    IFS=. read -a octets <<< "$ip";
    set -- "${octets[@]}";
    min_ip=$(($1*256*256*256 + $2*256*256 + $3*256 + $4));
    host=$((32-mask))
    max_ip=$(($min_ip+(2**host)-1))
    printf "%d-%d\n" "$min_ip" "$max_ip"
}

check_overlap () {
    IFS=- read min1 max1 <<< "$(read_range $1)";
    IFS=- read min2 max2 <<< "$(read_range $2)";
    if [ "$max1" -lt "$min2" ] || [ "$max2" -lt "$min1" ]; then return 0; fi
    return 1
}
