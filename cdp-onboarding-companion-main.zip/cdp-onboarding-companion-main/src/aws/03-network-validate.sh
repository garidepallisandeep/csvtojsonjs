# TO DO
# To validate if CDP control plane subnet is accessible
# Tutorial https://www.tutorialspoint.com/unix/unix-shell-functions.htm & https://www.freecodecamp.org/news/bash-array-how-to-declare-an-array-of-strings-in-a-bash-script/

#Full command curl https://test.v2.ccm.eu-1.cdp.cloudera.com --insecure -s -o /dev/null -w "%{http_code}" > $StatusCode && if [ $StatusCode -eq 404 ] || [ $StatusCode -eq 200 ]; then echo Reacheable; else echo NOT REACHABLE HttpStatus=$StatusCode;fi

source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh

#Running https CHECKS
log "CHECKING HTTPS ENDPOINTS" "INFO"
overallstatus=0

echo "| ================================================================================== |"
printf "| %-60s | %-10s | \n" "Endpoint URL" "Validation Result  "
echo "| ================================================================================== |"


# AWS Europe Testing
if [ "$CSP" = "aws" ] && [ "$CDPcontrolplaneregion" = "EU" ]; then
  for i in `cat $nw_endpoints | jq -r '.aws_common_eu[]','.data_hub[]','.data_services_eu[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

# AWS USA Testing
if [ "$CSP" = "aws" ] && [ "$CDPcontrolplaneregion" = "US" ]; then
  for i in `cat $nw_endpoints | jq -r '.aws_common_us[]','.data_hub[]','.data_services_us[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

# AWS APAC Testing
if [ "$CSP" = "aws" ] && [ "$CDPcontrolplaneregion" = "AP" ]; then
  for i in `cat $nw_endpoints | jq -r '.aws_common_ap[]','.data_hub[]','.data_services_ap[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

## @Adrian use logic to auto-discover the directory

#echo "CHECKING NOT HTTP ENDPOINTS"
#for i in ${!AWS_endpoints_Array[@]}; do
#        echo "Testing Endpoint nº$i: ${AWS_endpoints_Array[$i]}"
#        check_nonhttp ${AWS_endpoints_Array[$i]}
#        #Use the return output instead of first line echo for later styling human read
#        #return=$?
#done
echo "| ================================================================================== |"

state "Network validation status" $overallstatus

## Check Final Status of Network Validation and Report to Error File.
if [ "$overallstatus" -eq 1 ]; then
  print_header "Network Validation Failure Details" >> ${ERROR_FILE}
  cat $OUTPUT_DIR/tmp_network_output >> ${ERROR_FILE}
  echo "" >> ${ERROR_FILE}
  message="${RED} Some Network Endpoints are UNREACHABLE. Recommended Actions to solve it:\n "
  message+="${GREEN} Please be sure all CDP AWS Outbound Endpoints are reachable. Check your Security Groups, NACLs & Firewalls. ${NORMAL} \n "
  message+="${GREEN} Refer https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-aws/topics/mc-outbound_access_requirements.html for details ${NORMAL}\n "
  message+="${GREEN} Review the log file out/$LOG_FILE to find the specific non-reachable endpoint details ${NORMAL}\n "
  printf "${message}" >> ${ERROR_FILE}
  rm -f $OUTPUT_DIR/tmp_network_output
fi