#!/bin/bash
#############################################################
## Validate cross-account IAM policy
## Validate these here: https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-aws/topics/mc-aws-req-credential.html#mc-aws-req-credential
## Validate https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-aws/topics/mc-idbroker-minimum-setup.html#mc-idbroker-minimum-setup
## Current state: The below is only a framework, we need to assume each of the roles in the above documentation and validate if the appropriate policies are applied.
#############################################################

# Import Common Functions from common Script.
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh
EPOCHNOW=`date +%s`
IAM_TEMP_ERROR_FILE="out/iam_$(basename ${ERROR_FILE})"

# Set Variables
export fail_counter=0

POLICIES_DIR_PATH="$(cd $(dirname $0); pwd -L)/../../src/aws/policies"
DATALAKE_ADMIN_ROLE_POLICIES=("aws-cdp-ranger-audit-s3-policy" "aws-cdp-bucket-access-policy" "aws-datalake-backup-policy" "aws-datalake-restore-policy")
IDBROKER_ROLE_POLICIES=("aws-cdp-log-policy")
LOG_ROLE_POLICIES=("aws-cdp-log-policy" "aws-datalake-restore-policy")
RANGER_AUDIT_ROLE_POLICIES=("aws-cdp-ranger-audit-s3-policy" "aws-cdp-bucket-access-policy" "aws-datalake-backup-policy" "aws-datalake-restore-policy")
CROSS_ACCOUNT_DEFAULT_POLICIES=("aws-environment-minimal-policy")

#############################################################
# Function : fetch_policy_json
# Description : Fetch required json policy from github repo.
#############################################################
function fetch_policy_json()
{
  POLICY_NAME=${1}
  URL=${2}
  curl -s ${URL} > "${POLICIES_DIR_PATH}/${POLICY_NAME}"
  PYTHON_PATH=$(which python3)
  eval ${PYTHON_PATH} src/aws/flatten-iam-policy.py --policyfile "${POLICIES_DIR_PATH}/${POLICY_NAME}"
}

#############################################################
# Function : validate_trust_principal
# Description : Validate Role Trust Policy.
#               Datalake admin role should have idbroker role as trusted principle.
#               So that id broker role can assume Data Lake Admin Role.
#               DataLake Admin & Ranger Audit Role : IDBROKER Role.
#               IDbroker Role and Log Role : ec2.amazonaws.com
#############################################################
function validate_trust_principal()
{
  ROLE=${1}

  if [ ${ROLE} == ${datalake_admin_role} ] || [ ${ROLE} == ${ranger_audit_role} ] ; then
    PRINCIPLE=${idbroker_role}
    TRUST_PRINCIPAL=$(aws iam get-role --role-name  ${ROLE} | jq -r ".Role.AssumeRolePolicyDocument.Statement[].Principal.AWS" | awk -F "/" '{print $NF}')
  else
    PRINCIPLE="ec2.amazonaws.com"
    TRUST_PRINCIPAL=$(aws iam get-role --role-name  ${ROLE} | jq -r ".Role.AssumeRolePolicyDocument.Statement[].Principal.Service" | awk -F "/" '{print $NF}')
  fi

  print_banner
  if [[ ${PRINCIPLE} == ${TRUST_PRINCIPAL} ]]; then
    print_output "Assume Role is Configured Correctly For " "${ROLE}" "${PRINCIPLE}"
  else
    print_output "Assume Role : ${RED} ${ROLE} ${NORMAL} is not Configured Correctly With Trust Principal: ${PRINCIPLE}"
    log "Assume Role : ${RED} ${ROLE} ${NORMAL} is not Configured Correctly With Trust Principal: ${PRINCIPLE}" "${RED}ERROR${NORMAL}" >> ${IAM_TEMP_ERROR_FILE}
    echo "=============================================================================================================================" >> ${IAM_TEMP_ERROR_FILE}
    ((fail_counter=fail_counter+1))
  fi
  print_banner
}

#############################################################
# Function : validate_role
# Description : Simulate and Verify Given Account Policy
#               Loop through all services and get details from Policy file what permissions are reqired.
#               Extract permission action and resource type to prepare resource arn.
#               User simulate-principal-policy to check whether given permission actions is allowed or not.
#               Any Deny need to be report to Cloudera.
#############################################################

function validate_role()
{

  # Check if the role exists
  error_msg_array=()
  exit_code=$(aws iam get-role --role-name ${1})

  if [ $? -ne 0 ]
  then
    log "Role ${1} is Missing" "${RED}ERROR${NORMAL}"
    ((fail_counter=fail_counter+1))
    return
  else
    log "Role ${1} Found...Continuing to Test Further" "INFO"
  fi

  # Fetch arn for given role.
  print_header "Validating ${1}"
  IAM_ROLE_ARN=$(aws iam get-role --role-name ${1} | jq ".Role.Arn" | sed 's/"//g')
  echo "| ============================================================================================================================= |"
  for line in $(cat "${POLICIES_DIR_PATH}/${ROLE_TO_VALIDATE}.csv")
  do
    _actions=$(echo $line | awk -F '#' '{print $3}')
    _resource=$(echo $line | awk -F '#' '{print $4}')
    _condition=$(echo $line | awk -F '#' '{print $5}')
    if [[ "X${_resource}"  ==  "X*" ]]; then
      _resource_arn="*"
    else
      _resource_arn=$(eval echo ${_resource})
    fi

    if [[ -z "${_condition}" ]]; then
      DECISION=$(aws iam simulate-principal-policy --policy-source-arn "${IAM_ROLE_ARN}" --action-names "${_actions}"  --resource-arns "${_resource_arn}" --output json | jq .EvaluationResults[0].EvalDecision|sed 's/"//g')
    else
      DECISION=$(aws iam simulate-principal-policy --policy-source-arn "${IAM_ROLE_ARN}" --action-names "${_actions}"  --resource-arns "${_resource_arn}" --context-entries "${_condition}" --output json | jq .EvaluationResults[0].EvalDecision|sed 's/"//g')
    fi

    if [[ ${DECISION} == "allowed" ]]; then
      printf "| %-50s | %-30s | %-50s | %-50s |\n" "${_actions}" "${GREEN} ${DECISION} ${NORMAL}" "${_resource_arn}" "${_condition}" 
    else
      printf "| %-50s | %-30s | %-50s | %-50s |\n" "${_actions}" "${RED} ${DECISION} ${NORMAL}" "${_resource_arn}" "${_condition}" 
      ((fail_counter=fail_counter+1))
      error_msg_array+=("${_actions},${_resource_arn}")
    fi
  done
  echo "| ============================================================================================================================= |"

  # If Any permission found missing for a role. Report it to error file.
  if [ ${#error_msg_array[@]} -ne 0 ]; then
    if ! [ -e $IAM_TEMP_ERROR_FILE ]; then
      print_header "IAM Validation Failure Details" >> ${IAM_TEMP_ERROR_FILE}
    fi
    printf "[${RED} ERROR ${NORMAL}] Missing Permission For Role ${RED} ${1} ${NORMAL}\n" >> ${IAM_TEMP_ERROR_FILE} 
    for action in ${error_msg_array[@]}
    do
      _missing_permission=$(echo ${action} | awk -F ',' '{print $1}')
      _resource=$(echo ${action} | awk -F ',' '{print $2}')
      printf "| Missing %-30s on %-50s |\n" "${RED} ${_missing_permission} ${NORMAL}" "${_resource}"  >> ${IAM_TEMP_ERROR_FILE}
    done
    echo "============================================================================================================================= " >> ${IAM_TEMP_ERROR_FILE}
  fi
}

#############################################################
# Function : combine_policy_files
# Description : Combine all allowed policies for a Role
#############################################################
function combine_policy_files()
{
  ROLE_POLICIES=("$@")
  POLICY_FILE_NAME="${ROLE_TO_VALIDATE}.csv"

  # Remove if file already exist from an old run
  if [ -f "${POLICIES_DIR_PATH}/${POLICY_FILE_NAME}" ]; then
    rm -f "${POLICIES_DIR_PATH}/${POLICY_FILE_NAME}"
  fi

  for role in ${ROLE_POLICIES[@]}
  do
    cat "${POLICIES_DIR_PATH}/${role}.csv" | grep -v "^#Effect#Action#Resource#Condition" | sed -e 's/<BACKUP_LOCATION_BASE>/${BACKUP_LOCATION_BASE}/g' -e 's/<your-backup-bucket>/${BACKUP_LOCATION_BASE}/g' >> "${POLICIES_DIR_PATH}/${POLICY_FILE_NAME}"
  done
}

#############################################################
# Function : validate_cdp_roles
# Description : Validate permissions for IAM roles.
#############################################################
function validate_cdp_roles(){
  CDP_ROLE_NAME=${1}
  shift
  CDP_ROLE_POLICIES=("$@")

  export ROLE_TO_VALIDATE=${CDP_ROLE_NAME}
  combine_policy_files ${CDP_ROLE_POLICIES[@]}
  validate_role ${CDP_ROLE_NAME}
  validate_trust_principal ${CDP_ROLE_NAME}
}

#############################################################
# Function : main
# Description : main function.
#############################################################
function main()
{
  # Setting up Required parameters.
  ARN_PARTITION="aws"
  export STORAGE_LOCATION_BASE=$(eval echo "${storage_base_location}")
  export BACKUP_LOCATION_BASE=$(eval echo "${backup_location_base}")
  export DATALAKE_BUCKET="${bucket_name}"
  export LOGS_LOCATION_BASE=$(eval echo "${log_location_base}")
  export LOGS_BUCKET="${bucket_name}"

  print_header "Starting IAM Validation"

  # Fetch policies from Cloudera github Repo.
  for _policy in  ${cdp_log_policy} ${cdp_backup_policy} ${cdp_ranger_audit_s3_policy} ${cdp_datalake_admin_s3_policy} ${cdp_bucket_access_policy} ${datalake_backup_policy} ${datalake_restore_policy} ${cross_account_minimum_policy}
  do
    POLICY_NAME=$(basename ${_policy})
    fetch_policy_json ${POLICY_NAME} ${_policy}
  done

  export ROLE_TO_VALIDATE=${cross_account_role}
  combine_policy_files ${CROSS_ACCOUNT_DEFAULT_POLICIES[@]}

  # Validating Cross Account Role
  print_header "Validating Cross Account Role ${cross_account_role}"
  validate_role ${cross_account_role}

  # Validating Datalake Admin Role
  print_header "Validating Datalake Admin Role ${datalake_admin_role}"
  validate_cdp_roles ${datalake_admin_role} ${DATALAKE_ADMIN_ROLE_POLICIES[@]}

  # Validating ID Broker Role
  print_header "Validating Idbroker Role ${idbroker_role}"
  validate_cdp_roles ${idbroker_role} ${IDBROKER_ROLE_POLICIES[@]}

  # Validating Log Role
  print_header "Validating Log Role ${log_role}"
  validate_cdp_roles ${log_role} ${LOG_ROLE_POLICIES[@]}

  # # Validating Ranger Audit Role
  # print_header "Validating Ranger Audit Role ${ranger_audit_role}"
  # validate_cdp_roles ${ranger_audit_role} ${RANGER_AUDIT_ROLE_POLICIES[@]}
}

# Starting the program.
main
state "IAM validation" "$fail_counter"


# Merge Temp Error File to Main Error File
if [ -e $IAM_TEMP_ERROR_FILE ]; then
  message="Recommended Actions: "
  message+="${GREEN} Please fix above permission, to make IAM work for CDP Environment Provisioning ${NORMAL} \n" 
  message+="${GREEN} Refer https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-aws/topics/mc-idbroker-minimum-setup.html#mc-idbroker-minimum-setup for details ${NORMAL}\n "
  echo "" >> $IAM_TEMP_ERROR_FILE
  printf "${message}" >> $IAM_TEMP_ERROR_FILE
  print_banner >> ${IAM_TEMP_ERROR_FILE}
  cat ${IAM_TEMP_ERROR_FILE} >> ${ERROR_FILE}
  rm -f ${IAM_TEMP_ERROR_FILE}
fi