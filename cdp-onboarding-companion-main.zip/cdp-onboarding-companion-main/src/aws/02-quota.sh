#!/bin/bash

source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh
export fail_counter=0

# CONFIG_FILE=$1
# fetch_parameters_aws ${CONFIG_FILE}
# echo $region
# echo $vpc_count
# echo $subnets_count
# echo $internet_gateways_count
# echo $nat_gateways_coount
# echo $elastic_ips_count
# echo $elastic_loadbalancers_count
# echo $rds_db_instances_count
# echo $eks_clusters_count
# echo $ec2_instances_count

check_vpc_per_region ()
{
  service_code="vpc"
  vpcs_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="VPCs per Region") | .Value')
  vpcs_per_region_count=${vpcs_per_region%.*}
  created_vpcs_per_region=$(aws ec2 describe-vpcs --region $region | jq '.Vpcs | length')
  message="VPCs per Region"
  if [[ $vpcs_per_region -eq $created_vpcs_per_region ]];
    then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${vpcs_per_region}" "${created_vpcs_per_region}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))      
      echo -e "${RED} FAIL ${NC} $msg "VPCs quota available per region:$vpcs_per_region" "Created VPCs per region:${created_vpcs_per_region}" "Required VPCs:$vpc_count"">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the VPCs per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output
      if ! [ -e $OUTPUT_DIR/quota-output ]; then
        print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
      fi
      return 20;
  fi
  if [[ $vpcs_per_region_count -gt $created_vpcs_per_region ]];
    then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${vpcs_per_region}" "${created_vpcs_per_region}" "${GREEN} PASS ${NORMAL}"
      return 10;
    else
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${vpcs_per_region}" "${created_vpcs_per_region}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))
      echo -e "${RED} FAIL ${NC} $msg "VPCs quota available per region:$vpcs_per_region" "Created VPCs per region:${created_vpcs_per_region}" "Required VPCs:$vpc_count"" "Recommended Actions: ">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the VPCs per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output
      if ! [ -e $OUTPUT_DIR/quota-output ]; then
        print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
      fi      
      return 20;
  	fi;
}

check_internet_gateways ()
{
  service_code="vpc"
  internet_gateway_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="Internet gateways per Region") | .Value')
  internet_gateway_per_region_count=${internet_gateway_per_region%.*}
  created_internet_gateways=$(aws ec2 describe-internet-gateways --region $region | jq '.InternetGateways | length')
  #echo "Applied Service Quota for Internet gateways per Region : ${internet_gateway_per_region}"
  #echo "Internet Gateways Created per region : ${created_internet_gateways}"
  message="Internet Gateway per region"
  if [[ $internet_gateway_per_region_count -eq $created_internet_gateways ]]; then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${internet_gateway_per_region}" "${created_internet_gateways}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    echo -e "${RED} FAIL ${NC} $msg "Internet Gateways quota available per region:$internet_gateway_per_region" "Created Internet Gateways per region:${created_internet_gateways}" "Required Internet Gateways:$internet_gateways_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the Internet gateways per Region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output
    if ! [ -e $OUTPUT_DIR/quota-output ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    return 20;
  fi
  if [[ $internet_gateway_per_region_count -gt $created_internet_gateways ]]; then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${internet_gateway_per_region}" "${created_internet_gateways}" "${GREEN} PASS ${NORMAL}"
    #echo "${GREEN} PASS ${NORMAL} $message"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${internet_gateway_per_region}" "${created_internet_gateways}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    echo -e "${RED} FAIL ${NC} $msg "Internet Gateways quota available per region:$internet_gateway_per_region" "Created Internet Gateways per region:${created_internet_gateways}" "Required Internet Gateways:$internet_gateways_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the Internet gateways per Region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output
    if ! [ -e $OUTPUT_DIR/quota-output ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    return 20;
	fi;
}

check_nat_gateways ()
{
  service_code="vpc"
  nat_gateway_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="NAT gateways per Availability Zone") | .Value')
  nat_gateway_per_region_count=${nat_gateway_per_region%.*}
  created_nat_gateways=$(aws ec2  describe-nat-gateways --region $region | jq '.NatGateways | length')
  #  echo "Applied Service Quota for NAT gateways per Region : ${nat_gateway_per_region}"
  #  echo "NAT Gateways Created per region : ${created_nat_gateways}"
  message="NAT Gateways per region"
  if [[ $nat_gateway_per_region_count -eq $created_nat_gateways ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${nat_gateway_per_region}" "${created_nat_gateways}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "NAT Gateways quota available per region:$nat_gateway_per_region" "Created NAT Gateways per region:${created_nat_gateways}" "Required NAT Gateways:$nat_gateways_coount"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the NAT Gateways per availability zone to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output  
    return 20;
  fi
  if [[ $(( $nat_gateway_per_region_count - $created_nat_gateways )) -gt $nat_gateways_coount ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${nat_gateway_per_region}" "${created_nat_gateways}" "${GREEN} PASS ${NORMAL}"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${nat_gateway_per_region}" "${created_nat_gateways}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "NAT Gateways quota available per region:$nat_gateway_per_region" "Created NAT Gateways per region:${created_nat_gateways}" "Required NAT Gateways:$nat_gateways_coount"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the NAT Gateways per availability zone to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output   
    return 20;
	fi;
}


check_elastic_ips_per_region ()
{
    service_code="ec2"
    elastic_ips_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="EC2-VPC Elastic IPs") | .Value')
    elastic_ips_per_region_count=${elastic_ips_per_region%.*}
    created_elastic_ips_per_region=$(aws ec2 describe-addresses --region $region | jq '.Addresses | length')
    #echo "Applied Service Quota for ElasticIPs per Region : ${elastic_ips_per_region}"
    #echo "ElasticIPS Created per region : ${created_elastic_ips_per_region}"
    message="ElasticIPs per region"
    if [[ $(( $elastic_ips_per_region_count - $created_elastic_ips_per_region )) -lt $elastic_ips_count ]];then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${elastic_ips_per_region}" "${created_elastic_ips_per_region}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi      
      echo -e "${RED} FAIL ${NC} $msg "Elastic IPs quota available per region:$elastic_ips_per_region" "Created Elastic IPs per region:${created_elastic_ips_per_region}" "Required Elastic IPs per region:$elastic_ips_count"">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the EC2-VPC Elastic IPs per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/ec2/quotas/">>$OUTPUT_DIR/quota-output     
      return 20;
    fi
    if [[ $(( $elastic_ips_per_region_count - $created_elastic_ips_per_region )) -gt $elastic_ips_count ]];then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${elastic_ips_per_region}" "${created_elastic_ips_per_region}" "${GREEN} PASS ${NORMAL}"
      return 10;
    else
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${elastic_ips_per_region}" "${created_elastic_ips_per_region}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))
      if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
        print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
      fi      
      echo -e "${RED} FAIL ${NC} $msg "Elastic IPs quota available per region:$elastic_ips_per_region" "Created Elastic IPs per region:${created_elastic_ips_per_region}" "Required Elastic IPs per region:$elastic_ips_count"">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the EC2-VPC Elastic IPs per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/ec2/quotas/">>$OUTPUT_DIR/quota-output    
      return 20;
	fi;
}

check_elastic_loadbalancers_per_region ()
{
  service_code="elb"
  network_load_balancer_quota=$(aws elbv2 describe-account-limits --region $region --output json | jq '.Limits[] |  select(.Name=="network-load-balancers") |.Max')
  network_load_balancer_per_region=$(echo "$network_load_balancer_quota" | tr -d '"')
  network_load_balancer_per_region_count=${network_load_balancer_per_region%.*}
  
  gateway_load_balancers_per_region=$(aws elbv2 describe-account-limits --region ap-south-1 --output json | jq '.Limits[] |  select(.Name=="gateway-load-balancers") |.Max')
  gateway_load_balancer_per_region=$(echo "$gateway_load_balancers_per_region" | tr -d '"')
  gateway_load_balancer_per_region_count=${gateway_load_balancer_per_region%.*}

  network_load_balancer_list=$(aws elbv2 describe-load-balancers --region $region | jq '.LoadBalancers | length')
  classic_load_balancer_per_region=$(aws elb describe-load-balancers --region $region| jq '.LoadBalancerDescriptions | length')
  load_balancer_service_quota_list=$(( $network_load_balancer_per_region_count + $gateway_load_balancer_per_region_count ))
  created_load_balancer_list=$(( $network_load_balancer_list + $classic_load_balancer_per_region ))
  message="Elastic Load Balancers per region"

  if [[ $load_balancer_service_quota_list -eq $created_load_balancer_list ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${load_balancer_service_quota_list}" "${created_load_balancer_list}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "Load Balancer quota available per region:$load_balancer_service_quota_list" "Created loadbalancers per region:${created_load_balancer_list}" "Required loadbalancers per region:$elastic_loadbalancers_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the classic/network loadbalancers per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas">>$OUTPUT_DIR/quota-output   
    return 20;
  fi
  if [[ $(( $load_balancer_service_quota_list - $created_load_balancer_list )) -gt $elastic_loadbalancers_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${load_balancer_service_quota_list}" "${created_load_balancer_list}" "${GREEN} PASS ${NORMAL}"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${load_balancer_service_quota_list}" "${created_load_balancer_list}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "Load Balancer quota available per region:$load_balancer_service_quota_list" "Created loadbalancers per region:${created_load_balancer_list}" "Required loadbalancers per region:$elastic_loadbalancers_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the classic/network loadbalancers per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/elasticloadbalancing/quotas">>$OUTPUT_DIR/quota-output   
    return 20;
	fi;
}


check_rds_db_instances_per_region ()
{
  service_code="rds"
  rds_service_quota_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="DB instances") | .Value')
  rds_service_quota_per_region_count=${rds_service_quota_per_region%.*}
  created_rds_db_instances=$(aws rds describe-db-instances --region $region | jq '.DBInstances | length')

  #echo "Applied Service Quota for RDS DB Instances per Region : ${rds_service_quota_per_region}"
  #echo "RDS DB Instnaces Created per region : ${created_rds_db_instances}"
  message="RDS DB Instances per region"
  if [[ $(( $rds_service_quota_per_region_count - $created_rds_db_instances )) -lt $rds_db_instances_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${rds_service_quota_per_region}" "${created_rds_db_instances}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "RDS DB Instances quota available per region:$rds_service_quota_per_region" "Created RDS DB Instances per region:${created_rds_db_instances}" "Required RDS DB Instances per region:$rds_db_instances_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the RDS DB Instances per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/rds/quotas/L-7B6409FD">>$OUTPUT_DIR/quota-output  
    return 20;
  fi
  if [[ $(( $rds_service_quota_per_region_count - $created_rds_db_instances )) -gt $rds_db_instances_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${rds_service_quota_per_region}" "${created_rds_db_instances}" "${GREEN} PASS ${NORMAL}"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${rds_service_quota_per_region}" "${created_rds_db_instances}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "RDS DB Instances quota available per region:$rds_service_quota_per_region" "Created RDS DB Instances per region:${created_rds_db_instances}" "Required RDS DB Instances per region:$rds_db_instances_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the RDS DB Instances per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/rds/quotas/L-7B6409FD">>$OUTPUT_DIR/quota-output   
    return 20;
	fi;
}

check_eks_clusters_per_region ()
{
  service_code="eks"
  eks_service_quota_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="Clusters") | .Value')
  eks_service_quota_per_region_count=${eks_service_quota_per_region%.*}
  created_eks_clusters_per_region=$(aws eks list-clusters --region $region | jq '.clusters | length')
  message="EKS clusters per region"
  if [[ $(( $eks_service_quota_per_region_count - $created_eks_clusters_per_region )) -lt $eks_clusters_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${eks_service_quota_per_region}" "${created_eks_clusters_per_region}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "EKS Clusters quota available per region:$eks_service_quota_per_region" "EKS Clusters per region:${created_eks_clusters_per_region}" "Required EKS Clusters per region:$eks_clusters_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the EKS clusters quota per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/eks/quotas/L-1194D53C">>$OUTPUT_DIR/quota-output 
    return 20;
  fi
  if [[ $(( $eks_service_quota_per_region_count - $created_eks_clusters_per_region )) -gt $eks_clusters_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${eks_service_quota_per_region}" "${created_eks_clusters_per_region}" "${GREEN} PASS ${NORMAL}"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${eks_service_quota_per_region}" "${created_eks_clusters_per_region}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "EKS Clusters quota available per region:$eks_service_quota_per_region" "EKS Clusters per region:${created_eks_clusters_per_region}" "Required EKS Clusters per region:$eks_clusters_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the EKS clusters quota per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/eks/quotas/L-1194D53C">>$OUTPUT_DIR/quota-output  
    return 20;
	fi;
}

check_ec2_instances_per_region ()
{
  service_code="ec2"
  ec2_instances_quota_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region "$region" --output json | jq '.Quotas[] | select(.QuotaName=="Running On-Demand Standard (A, C, D, H, I, M, R, T, Z) instances") | .Value')
  ec2_instances_quota_per_region_count=${ec2_instances_quota_per_region%.*}
  created_ec2_instances_list=$(aws ec2 describe-instances --region "$region" --query 'Reservations[*].Instances[*].[InstanceId]' --output text | wc -l)
  #echo "Applied Service Quota for Ec2 Instances per Region : ${ec2_instances_quota_per_region}"
  #echo "EC2 Instances Created per region : ${created_ec2_instances_list}"
  message="Ec2 Instances per region"
  if [[ $(( $ec2_instances_quota_per_region_count - $created_ec2_instances_list )) -lt $ec2_instances_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${ec2_instances_quota_per_region}" "${created_ec2_instances_list}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "Ec2 Instances quota available per region:$ec2_instances_quota_per_region" "Ec2 Instances per region:${created_ec2_instances_list}" "Required Ec2 Instances per region:$ec2_instances_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the on-demand Standard Ec2 Instances per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/ec2/quotas/">>$OUTPUT_DIR/quota-output 
    return 20;
  fi
  if [[ $(( $ec2_instances_quota_per_region_count - $created_ec2_instances_list )) -gt $ec2_instances_count ]];then
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${ec2_instances_quota_per_region}" "${created_ec2_instances_list}" "${GREEN} PASS ${NORMAL}"
    return 10;
  else
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${ec2_instances_quota_per_region}" "${created_ec2_instances_list}" "${RED} FAIL ${NORMAL}"
    ((fail_counter=fail_counter+1))
    if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
      print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
    fi    
    echo -e "${RED} FAIL ${NC} $msg "Ec2 Instances quota available per region:$ec2_instances_quota_per_region" "Ec2 Instances per region:${created_ec2_instances_list}" "Required Ec2 Instances per region:$ec2_instances_count"">>$OUTPUT_DIR/quota-output
    echo -e "Recommended Actions:
Increase the on-demand Standard Ec2 Instances per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/ec2/quotas/">>$OUTPUT_DIR/quota-output   
    return 20;
	fi;
}

check_other_quotas_per_region ()
{
    service_code="vpc"
    subnets_per_vpcs_quota_per_region=$(aws service-quotas list-service-quotas --service-code $service_code --region $region --output json | jq '.Quotas[] | select(.QuotaName=="Subnets per VPC") | .Value')
    subnets_per_vpcs_quota_per_region_count=${subnets_per_vpcs_quota_per_region%.*}
    message="Applied Subnet quota per VPC per Region"
    #echo "Applied Subnet quota per VPC per Region : ${subnets_per_vpcs_quota_per_region}"
    printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${subnets_per_vpcs_quota_per_region}" "Minimum 6 subnets in the VPC" " "
      if [[ $subnets_per_vpcs_quota_per_region_count -eq $subnets_count ]];
    then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${subnets_per_vpcs_quota_per_region}" "${subnets_count}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))
      if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
        print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
      fi      
      echo -e "${RED} FAIL ${NC} $msg "Subnets per VPC quota available per region:$subnets_per_vpcs_quota_per_region" "Required Subnets per VPC per region:$subnets_count"">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the Subnets per VPC per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output     
      return 20;
  fi
  if [[ $subnets_per_vpcs_quota_per_region_count -gt $subnets_count ]];
    then
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${subnets_per_vpcs_quota_per_region}" "${subnets_count}" "${GREEN} PASS ${NORMAL}"
      return 10;
    else
      printf "| %-50s | %-30s | %-50s | %-30s |\n" "${message}" "${subnets_per_vpcs_quota_per_region}" "${subnets_count}" "${RED} FAIL ${NORMAL}"
      ((fail_counter=fail_counter+1))
     if [ ! -s "$OUTPUT_DIR/quota-output" ]; then
        print_header "Quota Validation Failure Details" >> $OUTPUT_DIR/quota-output
      fi      
      echo -e "${RED} FAIL ${NC} $msg "Subnets per VPC quota available per region:$subnets_per_vpcs_quota_per_region" "Required Subnets per VPC per region:$subnets_count"">>$OUTPUT_DIR/quota-output
      echo -e "Recommended Actions:
Increase the Subnets per VPC per region to the required quota using this link:https://console.aws.amazon.com/servicequotas/home/services/vpc/quotas/L-407747CB">>$OUTPUT_DIR/quota-output
      return 20;
  	fi;
}

print_header "AWS Service Quota validation (for onboarding to CDP:)"
log "Checks are starting..." "INFO"
echo "| ================================================================================================================================================================ |"
printf "| %-50s | %-30s | %-50s | %-30s |\n" "Resource" "Applied Service Quota" "Current utilisation" "Status"
echo "| ================================================================================================================================================================ |"

#log "check_ec2_instances_per_region checks started"
check_ec2_instances_per_region
#log "check_rds_db_instances_per_region checks started"
check_rds_db_instances_per_region
#log "check_eks_clusters_per_region checks started"
check_eks_clusters_per_region
#log "check_vpc_per_region checks started"
check_vpc_per_region
#log "check_internet_gateways checks started"
check_internet_gateways
#log "check_nat_gateways checks started"
check_nat_gateways
#log "check_elastic_loadbalancers_per_region checks started"
check_elastic_loadbalancers_per_region
#log "check_elastic_ips_per_region checks started"
check_elastic_ips_per_region
#log "check_other_quotas_per_region checks started"
check_other_quotas_per_region

if [[ -f "$OUTPUT_DIR/quota-output" ]]; then
    cat $OUTPUT_DIR/quota-output >> ${ERROR_FILE}
    print_banner >> ${ERROR_FILE}
    rm -rf $OUTPUT_DIR/quota-output
fi

echo "| ================================================================================================================================================================ |"
state "Quota Validation" "$fail_counter"