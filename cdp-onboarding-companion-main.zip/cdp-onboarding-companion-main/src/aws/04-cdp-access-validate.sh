#!/bin/bash
## This should eventually move into a central config file

#############################################################
##### Validate if CDP admin access rights are available & CDP CLI works
#############################################################

## Mechanism 1: See if we can register a new credential
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh
export fail_counter=0
cdpadmin=$(cdp iam list-roles | jq .roles | grep crn | grep -v Policy | awk -F ':' '{print $(NF-0)}' | grep EnvironmentAdmin | tr -d '",')
if [ -z "$cdpadmin" ]
then
    print_output "Missing cdp admin access,you Cannot provision Environment" 
    ((fail_counter=fail_counter+1))
else
    print_output "CDP CLI is setup and you have CDP admin access to create credentials"
fi
state "CDP Admin Validation" "$fail_counter"
