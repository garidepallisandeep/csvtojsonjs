#!/usr/bin/env python3
############################################################
# File : flatten-iam-policy.py
# Description : Flatten an IAM policy json to a csv format/
############################################################

import json
import pandas as pd
import sys, getopt
import os

############################################################
# Name : parseargs
# @input : argv : command line arguments.
# @output : Policy Json file.
# Description : Flatten an IAM policy json to a csv format.
############################################################
def parseargs(argv):
  ''' Parse command Line Arguments.
      Parameters:
      argv : command line arguments.

      Returns:
      file_name : Json policy file which needs to be flatten. 
  '''
  opts, args = getopt.getopt(argv,"hi:p:",["help","policyfile="])
  for opt, arg in opts:
    if opt in ("-h","--help"):
      print ('python flatten-iam-policy.py -p <iamjsonpolicyfile>')
      sys.exit()
    elif opt in ("-p", "--policyfile"):
      policy_json_file = arg
      return(policy_json_file)


###########################################################
# Name : flatten_iam_conditions
# @input : policy_data : IAM policy in Json format.
# @output : policy_data : IAM policy in Json format with flattan IAM condition.
# Description : Flatten an IAM policy condition to context.
############################################################
def flatten_iam_conditions(policy_data):
  ''' function to convert IAM condition from json to a flat context-entries.
      Arguments:
      policy_data : json format IAM policy.
      input :  "Condition": {
                 "StringLike": {
                    "ec2:ResourceTag/Cloudera-Resource-Name": ["crn:cdp:*"]
                  }
                }
      Returns:
      policy_data : json format IAM policy but with flatten condition.
      output : ContextKeyName='ec2:ResourceTag/Cloudera-Resource-Name',ContextKeyValues=['crn:cdp:*'],ContextKeyType=string

  '''
  condition=[]
  for key, value in (policy_data['Condition']['StringLike']).items():
    condition =f"ContextKeyName='{key}',ContextKeyValues={value},ContextKeyType=string" 
  policy_data['Condition'] = condition
  return policy_data



############################################################
# Name : main
# @input : argv : command line arguments.
# @output : None
# Description : Flatten an IAM policy json to a csv format.
############################################################
def main(argv):
  ''' main function to convert a json IAM policy file to csv file.
      function extracts requires keys 'Effect', 'Action', 'Resource' and 'Condition'
      Arguments:
      argv : Command line argumens passed to program.

      Retruns: None
  '''
  filepath = parseargs(argv[1:])
  fname = os.path.splitext(os.path.basename(filepath))[0]
  dirpath = os.path.dirname(filepath)
  policy_list = []

  with open(filepath) as json_file:
    data = json.load(json_file)

  for policy in data["Statement"]:
    if 'Condition' in policy.keys():
      policy = flatten_iam_conditions(policy)
    else:
      policy['Condition']=""
    policy_list.append(policy)
  df = pd.DataFrame.from_dict(policy_list)
  df = df[['Effect','Action','Resource','Condition']]  # Selecting Required Keys only
  df = df.explode("Action")
  df = df.explode("Resource")
  df.to_csv(f'{dirpath}/{fname}.csv',sep='#')


if __name__ == '__main__':
  main(sys.argv)