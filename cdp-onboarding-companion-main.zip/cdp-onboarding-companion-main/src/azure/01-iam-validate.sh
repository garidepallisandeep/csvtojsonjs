#!/bin/bash

# Usage: 01-iam-validate.sh <path to config file>

source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh
print_header "Azure User Permission validation"
print_banner

which az > /dev/null 2>&1
if [ $? -ne 0 ]; then
    state "Cannot find Azure Cli. Please install Azure Cli." 1
    exit 1
fi
which jq > /dev/null 2>&1
if [ $? -ne 0 ]; then 
    state "Cannot find jq. Please install jq. " 1
    exit 1
fi

configFile=$1

if test -f "$configFile"; then
    log "Using config file $configFile"
else
    state "config file $configFile doesn't exist. Please provide valid path to config file." 1
    exit 1
fi
### User permission precheck
# - Use current user as Cloud administrator, retrieve the role of current user, retrieve the AAD role for the current user.
# - If SPN is not provided:
#   - Azure AD role for cloud administrator must be `Application Developer`
#   - Azure subscription admin role must at least has resource group level `User Access Administrator`, prefer to be `Owner`
# - Check the custom role existence and required permission
# - If SPN and SPN secret are provided
#   - take SPN and SPN secret from the yaml file to confirm whether it can be used to login. 
#   - If SPN is not assigned `contributor` role or one of the three custom roles of subscription or resource group, Azure subscription admin role must at least has resource group level `User Access Administrator`, prefer to be `Owner`
# - If SPN is granted Contributor role
#   - permission is good to proceed environment registration
# - else
#   - check existence of custom role and validate whether the custom role is assigned to SPN.
#   - custom role validate is not part of this version.


# Checking login status and retrieve current login user
resp=$(az ad signed-in-user show 2>/dev/null)
# must be in a logged in context
if [ $? -ne 0 ]; then
    state "User is not singed in. Please run 'az login' to setup account." 1
    exit 2
fi

userMail=$(echo $resp |jq .mail|tr -d '"')
userID=$(echo $resp |jq .id|tr -d '"')
log "Cloud administrator ID is \"$userID\""

if [ "$userMail" = "" ] || [ "$userID" = "" ]; then
    state "Failed to retrieve current signed in user ID." 1
    exit 2
fi

resp=$(az account show)
subscriptionName=$(echo $resp|jq .name|tr -d '"')
subscriptionId=$(echo $resp|jq .id|tr -d '"')
tenantId=$(echo $resp|jq .homeTenantId|tr -d '"')
log "Using Subscription \"$subscriptionName\" with ID \"$subscriptionId\" in tenant ID \"$tenantId\" "

environmentResourceGroup=$(cat $configFile | jq .environmentResourceGroup | tr -d '"' 2>/dev/null )
if [ -z $environmentResourceGroup ] || [ "$environmentResourceGroup" = "null" ]; then
  scope="/subscriptions/${subscriptionId}"
else
  scope="/subscriptions/${subscriptionId}/resourceGroups/${environmentResourceGroup}"
fi
## Retrieve role of cloud administrator
log "Permission scope is set to \"$scope\". "
rolesOfCloudAdmin=$(az role assignment list --include-inherited --assignee $userID --scope $scope|jq ".[].roleDefinitionName" |tr -d '"')

echo $rolesOfCloudAdmin|grep -wq "Owner"
if [ $? -eq 0 ]; then
  adminRole="Owner"
else
  echo $rolesOfCloudAdmin |grep -wq "User Access Administrator"
  if [ $? -eq 0 ]; then
    adminRole="User Access Administrator"
  else
    adminRole=$rolesOfCloudAdmin
  fi
fi

log "Role of Cloud Administrator is $adminRole"

# Retrieve and validate location
location=$(cat ${configFile}| jq .required.region|tr -d '"')
if [ "$location" = '' ]; then 
  state "location must be provided in config file." 1
else
  az account list-locations|jq ".[].name"|grep -wq $location
  if [ $? -ne 0 ]; then
    state "Invalid location provided, $location." 1
  else
    state "Location provided as $location." 0
  fi
fi

# Retrieve and validate SPN
SPN=$(cat ${configFile}|jq .servicePrincipal.SPN|tr -d '"')

if [ "$SPN" = "null" ] || [ "$SPN" = "" ]; then
  state "SPN is not provided. Checking whether Cloud Administrator has enough permission to create SPN" 2
  # - Azure AD role for cloud administrator must be `Application Developer`
  # AAD Administrator could be a different user. So, here we rely on the input from config file to retrieve the role.
  cloudAdminAADRole=$(cat ${configFile}|jq .cloudAdminAADRole | tr -d '"')
  if [ "$cloudAdminAADRole" = "null" ] || [ "$cloudAdminAADRole" = "" ]; then
    state "SPN is not provided in config file, and cloud administrator's AzureAD role is not provided. Cloud Administrator cannot create required SPN. " 1
  else
    log "Cloud administrator's AAD role is $cloudAdminAADRole"
    eligibleRole=("Application Administrator", "Application Developer", "Cloud Application Administrator", "AAD DC Administrators", "Company Administrator")
    echo "${eligibleRole[@]}" |grep -wq "$cloudAdminAADRole"
    if [ $? -ne 0 ]; then
      state "SPN is not provided in config file, and cloud administrator's AzureAD role is not able to create SPN." 1
    else
      state "SPN is not provided, but cloud administrator is eligible to create SPN." 0
    fi
  fi

  # - Azure subscription admin role must at least has resource group level `User Access Administrator`, prefer to be `Owner`
  if [ "$adminRole" = "Owner" ] || [ "$adminRole" = "User Access Administrator" ]; then
    state "Cloud administrator has privilege to grant proper permission to SPN." 0
  else
    state "Cloud Administrator does not have privilege to grant proper permission to SPN." 1
  fi

else
  # SPN is provided, validating SPN permission
  SPNRole=$(az role assignment list --include-inherited --assignee $SPN --scope $scope| jq ".[].roleDefinitionName" |tr -d '"')
  if [ "$SPNRole" = "null" ] || [ "$SPNRole" = "" ]; then
    state "SPN doesn't have a valid role assigned." 1
  else
    log "SPNRole is $SPNRole"
  fi

  echo $SPNRole | grep -wq "Contributor"
  if [ $? -ne 0 ]; then
    state "SPN is not assigned Contributor role. Custom role is acceptable, but for future data service deployment, contributor role will be required. " 2
    log "Validating custom roles"
    customRoleAssigned="false"

    singleRGServiceEndpointRole=$(cat ${configFile}|jq .servicePrincipal.singleRGServiceEndpointRole|tr -d '"')
    
    if [ "$singleRGServiceEndpointRole" = "null" ] || [ "$singleRGServiceEndpointRole" = "" ]; then
      log "single resource group with service endpoint role is not provide."
      singleRGServiceEndpointRole=""

    else
      echo $SPNRole | grep -wq "$singleRGServiceEndpointRole"
      if [ $? -eq 0 ]; then
        state "SPN role is assigned to singple resource group with service endpoint role." 0
        customRoleAssigned="true"
      fi
    fi

    singleRGPrivateEndpointRole=$(cat ${configFile}|jq .servicePrincipal.singleRGPrivateEndpointRole|tr -d '"')
    if [ "$singleRGPrivateEndpointRole" = "null" ] || [ "$singleRGPrivateEndpointRole" = "" ]; then
      log "Single resource group with private endpoint role is not provide."
      singleRGPrivateEndpointRole=""
    else
      echo $SPNRole | grep -wq "$singleRGPrivateEndpointRole"
      if [ $? -eq 0 ]; then
        state "SPN role is assigned to singple resource group with private endpoint role." 0
        customRoleAssigned="true"
      fi
    fi
  
    multiRGRole=$(cat ${configFile}|jq .servicePrincipal.multiRGRole|tr -d '"')
    if [ "$multiRGRole" = "null" ] || [ "$multiRGRole" = "" ]; then
      log "Multi resource group role is not provide."
      multiRGRole=""
    else
      echo $SPNRole | grep -wq "$multiRGRole"
      if [ $? -eq 0 ]; then
        state "SPN role is assigned to multi resource group role." 0
        customRoleAssigned="true"
      fi
    fi
    if [ "$customRoleAssigned" = "false" ]; then
      state "Custom role is not assigned, SPN Role $SPNRole doesn't contain Contributor. This may impact some data service provisioning. Please double check required services and make sure proper permission is assigned." 2
    
      if [ "$adminRole" = "Owner" ] || [ "$adminRole" = "User Access Administrator" ]; then
        # even cloud administrator has the permision to modify the role of the SPN, it is still in warning becuase the customer's governance may not allow this SPN to have proper permission.
        state "Cloud administrator has privilege to grant proper permission to SPN. Please consider whether change the SPN privilege." 2
      else
        state "SPN is not assigned Contributor role or any custom role, and Cloud Administrator does not have privilege to grant proper permission to SPN. CDP environment cannot be registered with thsi SPN. " 1
      fi
    fi
  else
  # SPN has contributor permission
    state "SPN has proper permission to conduct required operation." 0
  fi
fi

