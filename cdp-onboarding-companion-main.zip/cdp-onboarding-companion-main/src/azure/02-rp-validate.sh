#!/bin/bash

# importing functions from utils/common.sh
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh

print_header "Azure resource providers validation"

print_banner

# Below you can find the array that contains all the required resource providers for a CDP deployment. I added some unregistered resource providers to test the functionality.
# the final output should list them in order of PASS or FAIL. Regardless of the order in the array, they will get sorted by PASS or FAIL.

# test array for one occurence of an unregistered resource provider. Uncomment if you want to test and comment out the second array.
#declare resourceProvidersList=("Microsoft.Network" "Microsoft.Compute" "Microsoft.Storage" "Microsoft.ContainerService" "Microsoft.DBforPostgreSQL" "Microsoft.NetApp" "Dynatrace.Observability")
declare resourceProvidersList=("Microsoft.Network" "Microsoft.Compute" "Microsoft.Storage" "Microsoft.ContainerService" "Microsoft.DBforPostgreSQL" "Microsoft.NetApp")
declare registeredResourceProvider=()
declare unregisteredResourceProvider=()

# prints all the resource providers that are registered and have a PASS.
function print_registered() {
    for resourceProvider in ${registeredResourceProvider[@]}
    do
        state "$resourceProvider is registered" 0
    done
}

# prints all the resource providers that are not registered and have a FAIL.
function print_unregistered() {
    for resourceProvider in ${unregisteredResourceProvider[@]}
    do
        state "$resourceProvider is not registered" 1
    done
}

# print the status for each resource provider. If the status is not registered, attempt to register it. 
log "Starting resource providers check..."
print_banner
for resourceProvider in "${resourceProvidersList[@]}"
    do
        log "Checking $resourceProvider..."
        print_banner
        checkRegistration=$(az provider list --query "[?namespace=='$resourceProvider']"|jq ".[].registrationState" |tr -d '"')
        if [ $? -ne 0 ]; then 
            state "Invalid response from az provider list. Please try again or verify that the command is using proper syntax."
            exit 2
        fi

        if [ "$checkRegistration" == "Registered" ] 
            then
                registeredResourceProvider+=("$resourceProvider")
        else
            unregisteredResourceProvider+=("$resourceProvider")
            # add the unRegistered resource providers to this output file so that the customer can register them in Azure.
            log "The $resourceProvider resource provider is not registered."
        fi
    done

if [ "${#unregisteredResourceProvider[@]}" -eq 0 ]; 
    then
        print_registered
        print_banner
        log "All required resource providers are registered."
    else
        print_registered
        print_unregistered
        log "Please check the log file to check unregistred resource providers and please register them."
        log "To register it, please visit: https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/resource-providers-and-types#register-resource-provider-1"
fi

print_banner