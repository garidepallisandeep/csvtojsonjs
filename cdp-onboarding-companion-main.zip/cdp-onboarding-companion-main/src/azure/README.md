# cdp-az-helpers
- The goal of this project is to make prerequisite validation a very simple experience for customers & SAs
- Any tools used within this script should be portable & must work in any environment
- As a guide, the tools use the following components:
  - AZ CLI
  - CDP CLI
  - Bash
  - Python 3 with venv (this requirement can be eliminated if we pre-flatten json policy files into csv within a cloudera environment)
- The script takes input from a JSON file for configuration details.
- Should be run from a machine that has access to AWS CLI & CDP CLI, and supports bash
- Example expected final outcomes:

![Alt text](../../images/expectedoutput2.png)

## General Logic design
### Input
- Environment location: Mandatory

- User permission
  - SPN/SPN Secret: Optional
  - SPN role: optional, default to contributor
  - Custom role names: optional
    - Custom role name for `Single resource group with service endpoint`
    - Custom role name for `Single resource group with private endpoint`
    - Custom role name for `Multiple resource group`

- Pre-requisites resources
  - Resource group name: Mandatory
  - Storage account name: Optional
  - Managed Identitys: Optional
    - Azumer Identity Name
    - Data Access Identity Name
    - Ranger Identity Name
    - Logger Identity Name

- Network
  - Network resource group: Optional
  - VNET name: Optional
  - VNET CIDR range
  - subnet array: optional
  - NSG resource group name: optional
  - KNOX NSG name: optional
  - Default NSG Name: optional
  - Private DNS zone name: optional
  - Public interface allowed: Optional, default to false.

- Resource quota
  - Environment Type: Optional, default to light weight




### User permission precheck
- Use current user as Cloud administrator, retrieve the role of current user, retrieve the AAD role for the current user.
- If SPN is not provided:
  - Azure AD role for cloud administrator must be `Application Developer`
  - Azure subscription admin role must at least has resource group level `User Access Administrator`, prefer to be `Owner`
- Check the custom role existance and required permission
- If SPN and SPN secret are provided
  - take SPN and SPN secret from the yaml file to confirm whether it can be used to login. 
  - If SPN is not assigned `contributor` role or one of the three custom roles of subscription or resource group, Azure subscription admin role must at least has resource group level `User Access Administrator`, prefer to be `Owner`
- If Customer role names are not provided, assuming custom roles are not created
  - if SPN role is contributor, ignore this validation
  - else, check the existance of the role assigned to SPN.
- else, validate the existance of the custom roles.

### CDP Prerequisites resource test
- If the reource group can not be located, prerequisite resources are not created. User need have permission to create those resources. to achieve this objective:
  - Either Cloud administrator or SPN need to have permission to create Resource group, storage account, managed identity in the subscription.
  - Cloud administrator need have `User Access Administrator` permission to manage access to the resources.
- else
  - If only the resource group name is provided 
    - match the managed identity names with `assumer`, `data`, `ranger`, `logger` with the managed identities in the resource group to identify the required managed ids; match the storage account
    - match the storage account name in the resource group
  - If managed identity or storage account names cannot be identified
    - Either Cloud administrator or SPN need to have permission to create Resource group, storage account, managed identity in the subscription.
    - Cloud administrator need have `User Access Administrator` permission to manage access to the resources.
  - else
    - Check the type of storage account
    - Check containers in the storage account
    - Check permissions for managed identity

### Network check
- If network resource group or VNET name is not provided, assuming CDP will create the VNET and subnets; it has to be public facing, cause CDP cannot do network peering on behalf of the customer.
  - Public interface must be allowed
  - VNET CIDR must be provided
  - CIDR range must be enough for environment registration
  - Check conflict of VNET CIDR vs CDP reserved CIDR
  - Subnet information will be ignored
  - Private DNS zone check is ignored
- else
  - Get CIDR range from VNET, and check conflict with CDP reserved CIDR
  - Retrieve subnets from VNET and check CIDR range compatability, and print out which subnet is suitable for CDP deployment
  - Minumum two suitable subnets available for CDP deployment.
- If security group
- Firewall check
  - If network resource group or VNET name is not provided, assuming CDP will create the VNET and subnets. There is no way to test the firewall rules. 
  - If Public interface is not allowed, firewall must allow the destination https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-azure/topics/mc-outbound_access_requirements.html
    - this check can only be run in customer's VNET environment.
  - else If network resource group or VNET name is not provided, 



### Resource quota pre-check
- Resource quota pre-check is based on resource consumption requirement. But since CDP provides a lot of data services, and it is not able to predict which and how many of these services will be used by the customer, it is not possible to evaluate all the quota requirement. So here the script will only check the requirement for environment registration and datalake. 
