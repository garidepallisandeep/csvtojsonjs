#!/bin/bash

# importing functions from utils/common.sh
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh

print_header "Azure Prerequisite Resource Validation"

print_banner
which az > /dev/null 2>&1
if [ $? -ne 0 ]; then 
    state "Cannot find Azure Cli. Please install Azure Cli" 1
    exit 1
fi
which jq > /dev/null 2>&1
if [ $? -ne 0 ]; then 
    state "Cannot find jq. Please install jq. " 1
    exit 1
fi

configFile=$1

if test -f "$configFile"; then
    log "Using config file $configFile"
else
    state "Config file $configFile doesn't exist. Please provide valid path to config file." 1
    exit 1
fi
### CDP Prerequisites resource test
# - If the reource group can not be located, prerequisite resources are not created. User need have permission to create those resources. to achieve this objective:
#   - Either Cloud administrator or SPN need to have permission to create Resource group, storage account, managed identity in the subscription.
#   - Cloud administrator need have `User Access Administrator` permission to manage access to the resources.

# Checking login status and retrieve current login user
resp=$(az ad signed-in-user show)
# must be in a logged in context
if [ $? -ne 0 ]; then
    state "User is not singed in. Please run 'az login' to setup account." 1
    exit 2
fi

userID=$(echo $resp |jq .id|tr -d '"')

if [ "$userID" = "" ]; then
    state "Failed to retrieve current signed in user ID." 1
    exit 2
fi
resp=$(az account show)
subscriptionId=$(echo $resp|jq .id|tr -d '"')

rgName=$(cat $configFile|jq .prerequisiteResources.resourceGroupName|tr -d '"')
if [ "$rgName" = "" ] || [ "$rgName" = "null" ]; then
    log "Resource group name is not provided in config file. Assuming prerequisite resources are not created. Validating user permission to create the resources."
    rgName=""
    scope="/subscriptions/${subscriptionId}"
else
    az group list |jq ".[].name"|tr -d '"'|grep -wq "$rgName"
    if [ $? -ne 0 ]; then
        state "Cannot find provided resource group name \"$rgName\" in the subscription." 1
        rgName=""
        scope="/subscriptions/${subscriptionId}"
    else
        scope="/subscriptions/${subscriptionId}/resourceGroups/${rgName}"
    fi
fi

## Retrieve role of cloud administrator for future validation
rolesOfCloudAdmin=$(az role assignment list --include-inherited --assignee $userID --scope $scope|jq ".[].roleDefinitionName" |tr -d '"')

echo $rolesOfCloudAdmin|grep -wq "Owner"
if [ $? -eq 0 ]; then
    adminRole="Owner"
else
    echo $rolesOfCloudAdmin |grep -wq "Contributor"
    if [ $? -eq 0 ]; then
        adminRole="Contributor"
    else
        adminRole=$rolesOfCloudAdmin
    fi
fi
if [ "$rgName" = "" ]; then
    if [ "$adminRole" = "Owner" ] || [ "$adminRole" = "Contributor" ]; then
        state "Prerequisite resources are not found, but user has permission to create those resources. " 0
    else
        state "The role of current role, $adminRole, may not have enough permission to create prerequisite resources. Please double check with administrator. "
    fi
    exit 0
fi

# Validate storage account existence
stgAcctName=$(cat $configFile|jq .prerequisiteResources.storageAccountName| tr -d '"')
if [ "$stgAcctName" = "null" ] || [ "$stgAcctName" = "" ]; then
    log "Storage account name is not provided in config file. Try matching the first storage account in the resource group."
    stgAcctName=$(az storage account list --resource-group $rgName |jq ".[].name"|tr -d '"'|head -n 1)
    if [ "$stgAcctName" = "" ] || [ "$stgAcctName" = "null" ]; then
        state "Cannot find storage account in resource group \"$rgName\". " 1
        stgAccountName=""
    else
        state "Found storage account \"$stgAcctName\" " 0
    fi
else
    az storage account show -n $stgAcctName -g $rgName >/dev/null 2>&1
    if [ $? -eq 0 ]; then
        state "Found storage account $stgAcctName" 0
    else
        state "Cannot find storage account $stgAcctName in resource group $rgName" 1
        stgAcctName=""
    fi
fi



# Validate Managed Identity existence
# Parameter: validate_identity_existence $rgName $configFile $identityPurpose
function validate_identity_existence(){
    rgName=$1; configFile=$2; identityPurpose=$3;
    identity=$(cat $configFile|jq ".prerequisiteResources.managedIdentities.$identityPurpose"|tr -d '"')
    if [ "$identity" = "null" ] || [ "$identity" = "" ]; then
        log "$identityPurpose identity name is not provided in config file. Try mattching the first managed identity with a name including \"$identityPurpose\" in the resource group. " >$(tty)
        identity=$(az identity list -g $rgName|jq ".[]|{\"name\":.name}|select(.name | test(\"$identityPurpose\"))|.name"|tr -d '"')
        if [ "$identity" = "null" ] || [ "$identity" = "" ]; then
            state "Cannot find $identityPurpose identity in resource group \"$rgName\"" 1
            identity=""
        else
            state "Found $identityPurpose identity \"$identity\" " 0
        fi
    else
        az identity show -n $identity -g $rgName >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            state "Found $identityPurpose Identity \"$identity\" " 0
        else
            state "Cannot find provided $identityPurpose identity \"$identity\" in resource group \"$rgName\"" 1
            identity=""
        fi
    fi
    echo $identity
}

assumerIdty=$(validate_identity_existence $rgName $configFile "Assumer")
dataIdty=$(validate_identity_existence $rgName $configFile "DataAccess")
rangerIdty=$(validate_identity_existence $rgName $configFile "Ranger")
loggerIdty=$(validate_identity_existence $rgName $configFile "Logger")


#   - If managed identity or storage account names cannot be identified
#     - Either Cloud administrator or SPN need to have permission to create Resource group, storage account, managed identity in the subscription.
#     - Cloud administrator need have `User Access Administrator` permission to manage access to the resources.
if [ "$stgAcctName" = "" ] || [ "$assumerIdty" = "" ] || [ "$dataIdty" = "" ] || [ "$rangerIdty" = "" ] || [ "$loggerIdty" = "" ]; then
    if [ "$adminRole" = "Owner" ] || [ "$adminRole" = "Contributor" ]; then
        state "At least one prerequisite resource is missing. But the user has permission to create resources. " 2
    else
        state "At least one prerequisite resource is missing. The current user role \"$adminRole\" may not have enough permission to create the resource. Please double check with cloud administrator. " 2 
    fi
fi

# Validate container parameter: validate_container $configFile $storageAccountName $containerPurpose $storageAccountKey
function validate_container(){
    confgiFile=$1; stgAcctName=$2; containerPurpose=$3; stgAcctKey=$4
    containerName=$(cat $configFile|jq ".prerequisiteResources.containers.$containerPurpose"|tr -d '"')
    if [ "$containerName" = "null" ] || [ "$containerName" = "" ]; then
        log "$containerPurpose container name is not provided in config file. Try matching container names with \"$containerPurpose\" in storage account" > $(tty)
        containerName=$(az storage container list --account-key $stgAcctKey --account-name $stgAcctName|jq ".[].name"|grep -i $containerPurpose|tr -d '"'|head -n 1)
        if [ "$containerName" != "" ]; then
            state "Matching container \"$containerName\" as $containerPurpose container. " 0
        else
            if [ "$containerPurpose" != "backup" ]; then
                state "Couldn't match any $containerPurpose container in storage account $stgAcctName ." 1
            fi
        fi
    else
        az storage container show --name $containerName --account-key $stgAcctKey --account-name $stgAcctName >/dev/null 2>&1
        if [ $? -eq 0 ]; then
            state "Found $containerPurpose container \"$containerName\"." 0
        else
            if [ "$containerPurpose" != "backup" ]; then
                state "Cannot find $containerPurpose container \"$dataContainerName\" in storage account \"$stgAcctName\"." 1
            fi
            containerName=""
        fi
    fi
    echo $containerName
}
# parameters: validate_mgmt_identity_permission $identityId $identityName $roleName $roleId $scope
function validate_mgmt_identity_permission(){
    identityId=$1; identityName=$2 roleName=$3; roleId=$4; scope=$5
    assignedRoles=$(az role assignment list --assignee $identityId --scope $scope|jq ".[].roleDefinitionId"|tr -d '"')
    if $(echo $assignedRoles|grep -wq $roleId); then 
        state "$roleName role is assigned to $identityName identity at \"$scope\". " 0
    else
        state "$roleName role is not assigned to $identityName identity at \"$scope\". " 1
    fi
}
if [ "$stgAcctName" != "" ]; then
    # - Check the type of storage account
    resp=$(az storage account show -n $stgAcctName -g $rgName)
    if [ "$(echo $resp|jq .kind|tr -d '"')" != "StorageV2" ]; then
        state "Storage account is not \"StorageV2\". Skipping managed identity permission check" 1
        exit 0
    else
        state "Storage account \"$stgAcctName\" is \"StorageV2\" Account." 0
    fi
    # - Check containers in the storage account
    stgAcctKey=$(az storage account keys list -n $stgAcctName -g $rgName|jq ".[].value"|head -n 1|tr -d '"')
    dataContainer=$(validate_container $configFile $stgAcctName "data" $stgAcctKey)
    logContainer=$(validate_container $configFile $stgAcctName "log" $stgAcctKey)
    backupContainer=$(validate_container $configFile $stgAcctName "backup" $stgAcctKey)
    # - Check permissions for managed identity
    subscriptionId=$(az account show|jq .id|tr -d '"')
    if [ "$assumerIdty" != "" ]; then
        identityObjId=$(az identity show -n $assumerIdty -g $rgName |jq .principalId|tr -d '"')
        # parameters: validate_mgmt_identity_permission $identityId $identityName $roleName $roleId $scope
        validate_mgmt_identity_permission $identityObjId "Assummer" "Managed Identity Operator" "f1a07417-d97a-45cb-824c-7a7467783830" "/subscriptions/$subscriptionId"
        validate_mgmt_identity_permission $identityObjId "Assummer" "Virtual Machine Contributor" "9980e02c-c2be-4d73-94e8-173b1dc7cf3c" "/subscriptions/$subscriptionId"
        if [ "$logContainer" != "" ]; then
            validate_mgmt_identity_permission $identityObjId "Assummer" "Storage Blob Data Contributor" "ba92f5b4-2d11-453d-a403-e96b0029c9fe" "/subscriptions/$subscriptionId/resourceGroups/$rgName/providers/Microsoft.Storage/storageAccounts/$stgAcctName/blobServices/default/containers/$logContainer"
        fi
    fi
    if [ "$dataIdty" != "" ]; then
        identityObjId=$(az identity show -n $dataIdty -g $rgName |jq .principalId|tr -d '"')
        if [ "$dataContainer" != "" ]; then
            validate_mgmt_identity_permission $identityObjId "DataAccess" "Storage Blob Data Owner" "b7e6dc6d-f1e8-4753-8033-0f276bb0955b" "/subscriptions/$subscriptionId/resourceGroups/$rgName/providers/Microsoft.Storage/storageAccounts/$stgAcctName/blobServices/default/containers/$dataContainer"
        fi
        if [ "$logContainer" != "" ]; then
            validate_mgmt_identity_permission $identityObjId "DataAccess" "Storage Blob Data Owner" "b7e6dc6d-f1e8-4753-8033-0f276bb0955b" "/subscriptions/$subscriptionId/resourceGroups/$rgName/providers/Microsoft.Storage/storageAccounts/$stgAcctName/blobServices/default/containers/$logContainer"
        fi
    fi
    if [ "$rangerIdty" != "" ] && [ "$dataContainer" != "" ]; then
        identityObjId=$(az identity show -n $rangerIdty -g $rgName |jq .principalId|tr -d '"')
        validate_mgmt_identity_permission $identityObjId "Ranger" "Storage Blob Data Contributor" "ba92f5b4-2d11-453d-a403-e96b0029c9fe" "/subscriptions/$subscriptionId/resourceGroups/$rgName/providers/Microsoft.Storage/storageAccounts/$stgAcctName/blobServices/default/containers/$dataContainer"
    fi
    if [ "$loggerIdty" != "" ] && [ "$logContainer" != "" ]; then
        identityObjId=$(az identity show -n $loggerIdty -g $rgName |jq .principalId|tr -d '"')
        validate_mgmt_identity_permission $identityObjId "Logger" "Storage Blob Data Contributor" "ba92f5b4-2d11-453d-a403-e96b0029c9fe" "/subscriptions/$subscriptionId/resourceGroups/$rgName/providers/Microsoft.Storage/storageAccounts/$stgAcctName/blobServices/default/containers/$logContainer"
    fi
fi

