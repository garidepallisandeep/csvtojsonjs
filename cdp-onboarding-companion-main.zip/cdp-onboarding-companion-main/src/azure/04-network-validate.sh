# TO DO
# To validate if CDP control plane subnet is accessible
# Tutorial https://www.tutorialspoint.com/unix/unix-shell-functions.htm & https://www.freecodecamp.org/news/bash-array-how-to-declare-an-array-of-strings-in-a-bash-script/

#Full command curl https://test.v2.ccm.eu-1.cdp.cloudera.com --insecure -s -o /dev/null -w "%{http_code}" > $StatusCode && if [ $StatusCode -eq 404 ] || [ $StatusCode -eq 200 ]; then echo Reacheable; else echo NOT REACHABLE HttpStatus=$StatusCode;fi

source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh

#Running https CHECKS
log "CHECKING HTTPS ENDPOINTS"
overallstatus=0

echo "| ================================================================================== |"
printf "| %-60s | %-10s | \n" "Endpoint URL" "Validation Result  "
echo "| ================================================================================== |"

#Azure PENDING
if [ "$CSP" = "azure" ]&& [ "$CDPcontrolplaneregion" = "US" ]; then
  for i in `cat $nw_endpoints | jq -r '.azure_common_us[]','.data_hub[]','.azure_data_services_us[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

if [ "$CSP" = "azure" ]&& [ "$CDPcontrolplaneregion" = "EU" ]; then
  for i in `cat $nw_endpoints | jq -r '.azure_common_eu[]','.data_hub[]','.azure_data_services_eu[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

if [ "$CSP" = "azure" ]&& [ "$CDPcontrolplaneregion" = "AP" ]; then
  for i in `cat $nw_endpoints | jq -r '.azure_common_ap[]','.data_hub[]','.azure_data_services_ap[]'`
  do
    #Modify regional Endpoints
    CHECK_PLACEHOLDERS=`echo $i | grep PLACEHOLDER | wc -l`;
    if [ $CHECK_PLACEHOLDERS -eq 1 ]; then
      i=`echo $i | sed s/PLACEHOLDER/$region/g`
    fi
    #Test HTTPS URL
    check_https_url $i
  done
fi

## @Adrian use logic to auto-discover the directory

#echo "CHECKING NOT HTTP ENDPOINTS"
#for i in ${!AWS_endpoints_Array[@]}; do
#        echo "Testing Endpoint nº$i: ${AWS_endpoints_Array[$i]}"
#        check_nonhttp ${AWS_endpoints_Array[$i]}
#        #Use the return output instead of first line echo for later styling human read
#        #return=$?
#done
echo "| ================================================================================== |"

state "Network validation status" $overallstatus
log "Network validation overall status code is $overallstatus"