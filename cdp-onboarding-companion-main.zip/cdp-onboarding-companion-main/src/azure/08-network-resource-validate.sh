#!/bin/bash

# Usage: 08-network-resource-validate.sh --config <path to config file> [ --admin-role <name of administrator role> ] [ --app-role <name of SPN role> ] 
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh
print_header "Azure Network Validation"
print_banner
while [[ $# -gt 0 ]] && [[ "$1" == "--"* ]] ;
do
    opt="$1";
    shift;
    case "$opt" in
        "--config" )
           configFile="$1"; shift;;
        "--admin-role" )
           adminRole="$1"; shift;;
        "--app-role" )
           appRole="$1"; shift;;
        *) echo >&2 "Invalid option: $@"; exit 1;;
   esac
done

which az > /dev/null 2>&1
if [ $? -ne 0 ]; then
    state "Cannot find Azure Cli. Please install Azure Cli." 1
    exit 1
fi
which jq > /dev/null 2>&1
if [ $? -ne 0 ]; then 
    state "Cannot find jq. Please install jq. " 1
    exit 1
fi

if test -f "$configFile"; then
    log "Using config file $configFile"
else
    state "config file $configFile doesn't exist. Please provide valid path to config file." 1
    exit 1
fi

# - If network resource group or VNET name is not provided, assuming CDP will create the VNET and subnets; it has to be public facing, cause CDP cannot do network peering on behalf of the customer.
#   - Public interface must be allowed
#   - VNET CIDR must be provided
#   - CIDR range must be enough for environment registration
#   - Check conflict of VNET CIDR vs CDP reserved CIDR
#   - Subnet information will be ignored
#   - Private DNS zone check is ignored
# - else
#   - Get CIDR range from VNET, and check conflict with CDP reserved CIDR
#   - Retrieve subnets from VNET and check CIDR range compatability, and print out which subnet is suitable for CDP deployment
#   - Minumum two suitable subnets available for CDP deployment.
# - If security group
# - Firewall check
#   - If network resource group or VNET name is not provided, assuming CDP will create the VNET and subnets. There is no way to test the firewall rules. 
#   - If Public interface is not allowed, firewall must allow the destination https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-azure/topics/mc-outbound_access_requirements.html
#     - this check can only be run in customer's VNET environment.
#   - else If network resource group or VNET name is not provided, 

resp=$(az ad signed-in-user show 2>/dev/null)
# must be in a logged in context
if [ $? -ne 0 ]; then
    state "User is not singed in. Please run 'az login' to setup account." 1
    exit 2
fi

userID=$(echo $resp |jq .id|tr -d '"')
resp=$(az account show)
subscriptionId=$(echo $resp|jq .id|tr -d '"')

rgName=$(cat $configFile|jq .network.vnetResourceGroupName|tr -d '"')
if [ "$rgName" = "" ] || [ "$rgName" = "null" ]; then
    log "Network resource group name is not provided in config file. Assuming network resources will be created by CDP control plane. "
    rgName=""
    scope="/subscriptions/${subscriptionId}"
else
    az group show -n $rgName >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        state "Cannot find provided resource group name \"$rgName\" in the subscription. Assuming network resources will be created by CDP control plane." 2
        rgName=""
        scope="/subscriptions/${subscriptionId}"
    else
        state "Found VNET Resouce Group" 0
        scope="/subscriptions/${subscriptionId}/resourceGroups/${rgName}"
    fi
fi

vnetName=$(cat $configFile|jq .network.vnetName|tr -d '"')
if [ "$vnetName" = "" ] || [ "$vnetName" = "null" ]; then
    vnetName=""
else
    if [ -z $rgName ]; then
        state "Incorrect configuration. \"vnetResourceGroup\" is not provided in config file, while vnetName is provide. Can not locate VNET without resource group name." 1
        vnetName=""
    else
        vnet=$(az network vnet show -n $vnetName -g $rgName 2>/dev/null)
        if [ $? -ne 0 ]; then
            state "Couldn't find VNET with name \"$vnetName\" under resource group \"$rgName\"." 1
            vnetName=""
        else
            state "Found VNET \"$vnetName\" in resource group \"$rgName\". " 0
        fi
    fi
fi


## Retrieve role of cloud administrator for future validation
if [ -z "$adminRole" ]; then
    adminRole=$(az role assignment list --include-inherited --assignee $userID --scope $scope|jq ".[].roleDefinitionName" |tr -d '"')
fi
echo $adminRole|grep -wq "Owner"
if [ $? -eq 0 ]; then
    adminRole="Owner"
else
    echo $adminRole |grep -wq "Contributor"
    if [ $? -eq 0 ]; then
        adminRole="Contributor"
    fi
fi

# Retrieve and validate location
location=$(cat ${configFile}| jq .required.region|tr -d '"')
if [ "$location" = '' ]; then 
  state "location must be provided in config file." 1
else
  az account list-locations|jq ".[].name"|grep -wq $location
  if [ $? -ne 0 ]; then
    state "Invalid location provided, $location." 1
  else
    state "Location provided as $location." 0
  fi
fi
if [ ! -z "$vnet" ]; then
    vnetLocation=$(echo $vnet|jq .location|tr -d '"')
    if [ "$location" != "$vnetLocation" ]; then
        state "VNET location \"$vnetLocation\" doesn't match config file location \"location\". " 1
        vnetName=""
    fi
fi

if [ -z "$vnetName" ]; then
    if [ "$adminRole" != "Owner" ] && [ "$adminRole" != "Contributor" ] && [ "$appRole" != "Owner" ] && [ "$appRole" != "Contributor" ]; then
        state "VNET is not found. The role of cloud administrator and SPN may not have enough permission to create prerequisite resources. Please double check with administrator. " 1
    else
        state "VNET is not found, but cloud admin or SPN has permission to create those resources. " 0
        if [ "$(cat $configFile|jq .network.publicIPAllowed|tr -d '"'|tr '[:upper:]' '[:lower:]')" = "true" ]; then
            state "Public IP is allowed." 0
        else
            state "If VNET doesn't exist, public IP must be allowed for CDP created resources to connect to CDP required internet resources. " 1
        fi
    
        vnetCIDR=$(cat $configFile|jq .network.vnetCIDR|tr -d '"')
        if [ -z $vnetCIDR ] || [ "$vnetCIDR" = "null" ]; then
            state "A CIDR range must be provided when CDP control plane provision the network." 1
        else
            if [[ $vnetCIDR =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+/[0-9]+$ ]]; then
                state "CIDR \"$vnetCIDR\" is a valid CIDR." 0
            else
                state "CIDR \"$vnetCIDR\" is invalid." 1
                vnetCIDR=""
            fi
        fi
        if [ ! -z $vnetCIDR ]; then
            SAVEIFS=$IFS; IFS="./" read -r ip1 ip2 ip3 ip4 N <<< "$vnetCIDR";  IFS=$SAVEIFS;
            if [ $N -gt 18 ]; then
                state "VNET CIDR provided doesn't have enough space to accomodate CDP environment. Required a /18 CIDR. Provided: /$N CIDR. " 1
            fi
            check_overlap $vnetCIDR "10.0.0.0/16" && check_overlap $vnetCIDR "10.244.0.0/16" && check_overlap $vnetCIDR "172.17.0.1/16" && check_overlap $vnetCIDR "10.20.0.0/16"
            if [ $? -ne 0 ]; then
                state "VNET CIDR range \"$vnetCIDR\" conflicts with one of the reserved CIDR \"10.0.0.0/16\", \"10.244.0.0/16\", \"172.17.0.1/16\", \"10.20.0.0/16\"" 1
            else
                state "VNET CIDR range \"$vnetCIDR\" does not conflicts with the reserved CIDR \"10.0.0.0/16\", \"10.244.0.0/16\", \"172.17.0.1/16\", \"10.20.0.0/16\"" 0
            fi
        fi
    fi
else
    vnetCIDR=($(echo $vnet|jq ".addressSpace.addressPrefixes[]"|tr -d '"'))
    
    for range in $vnetCIDR
    do
        check_overlap $range "10.0.0.0/16" && check_overlap $range "10.244.0.0/16" && check_overlap $range "172.17.0.1/16" && check_overlap $range "10.20.0.0/16"
        if [ $? -ne 0 ]; then
            state "VNET CIDR range \"$range\" conflicts with one of the reserved CIDR \"10.0.0.0/16\", \"10.244.0.0/16\", \"172.17.0.1/16\", \"10.20.0.0/16\"" 1
        else
            state "VNET CIDR range \"$range\" does not conflicts with one of the reserved CIDR \"10.0.0.0/16\", \"10.244.0.0/16\", \"172.17.0.1/16\", \"10.20.0.0/16\"" 0
        fi
    done
    subnetNames=($(cat $configFile| jq ".network.subnetNames[]" | tr -d '"' 2>/dev/null))
    if [ -z $subnetNames ] || [ "$subnetNames" = "null" ] || [ $(cat $configFile| jq ".network.subnetNames[]"|wc -l) -lt 2 ]; then
        # subnetNames is not provided or number of provided subnet is less than 2. check the subnets in the vnet
        # subnets=($(echo $vnet| jq ".subnets[]|{\"name\":.name, \"addressPrefix\":.addressPrefix}"))
        subnetCount=$(echo $vnet| jq ".subnets[].name"|wc -l)
        if [ $subnetCount -lt 2 ]; then
            state "There isn't enough subnets in VNET \"$vnetName\" for environment registration. " 1
        else
            eligibleSubnetNumber=0
            for (( i=0; i<=$subnetCount; i++ ))
            do
                subnetName=$(echo $vnet|jq ".subnets[$i].name"|tr -d '"')
                subnetCIDR=$(echo $vnet|jq ".subnets[$i].addressPrefix"|tr -d '"')
                if [ -z "$subnetCIDR" ] || [ "$subnetCIDR" = "null" ]; then continue; fi 
                SAVEIFS=$IFS; IFS="./" read -r ip1 ip2 ip3 ip4 N <<< "$subnetCIDR";  IFS=$SAVEIFS;
                if [[ $N < 23 ]]; then
                    state "Subnet \"$subnetName\" can be used for environment registration. " 0
                    eligibleSubnetNumber=$(($eligibleSubnetNumber + 1))
                fi
            done
            if [ $eligibleSubnetNumber -ge 2 ]; then
                state "There are $eligibleSubnetNumber eligible subnets for CDP environment registration. " 0
            else
                state "There isn't enough number of eligible subnet for for CDP environment registration. Required: 2; Eligible: $eligibleSubnetNumber" 1
            fi
        fi
    else
        # number of provided subnets is bigger than 1. Checking the existense of the subnets and it's CIDR.
        for ((i=0; i<${#subnetNames[@]}; i++))
        do
            obj=${subnetNames[$i]}
            echo $vnet|jq ".subnets[].name" |grep -wq $obj
            if [ $? -ne 0 ]; then
                state "Provided subnet name \"$subnetNames[$i]\" doesn't exist in VNET \"$vnetName\". " 1
            else
                state "Found subnet with name \"$obj\" in VNET \"$vnetName\". " 0
                subnetCIDR=$(echo $vnet|jq ".subnets[]|select (.name==\"$obj\")"|jq .addressPrefix|tr -d '"')
                if [ -z "$subnetCIDR" ] || [ "$subnetCIDR" = "null" ]; then
                    state "Cannot find CIDR range for subnet \"$obj\" in VNET \"$vnetName\" " 1
                else
                    SAVEIFS=$IFS; IFS="./" read -r ip1 ip2 ip3 ip4 N <<< "$subnetCIDR";  IFS=$SAVEIFS;
                    if [[ $N < 23 ]]; then
                        state "Subnet \"$obj\" can be used for environment registration. " 0
                    else
                        state "Subnet \"$obj\" cannot be used for environment registration. " 1
                    fi
                fi
            fi
        done
    fi
fi

# - If security group resource group or security group name is not provided
#   - Assuming cloud administrator will create them. Check cloud admin permission to create security group.
# - else
#   - validate existence of security group.
#   - Security rules validation: security rule cannot be validated cause there could be different combinations of ways to alow and deny traffic.


nsgRgName=$(cat $configFile|jq .network.nsgResourceGroupName|tr -d '"')
knoxNSGName=$(cat $configFile|jq .network.knoxNSGName|tr -d '"')
defaultNSGName=$(cat $configFile|jq .network.defaultNSGName|tr -d '"')
if [ -z $nsgRgName ] || [ "$nsgRgName" = "null" ] || [ -z $knoxNSGName ] || [ "$knoxNSGName" = "null" ] || [ -z $defaultNSGName ] || [ "$defaultNSGName" = "null" ]; then
    state "NSG info is not provided in config file, please make sure SPN has permission to create NSGs. " 2
else
    az group show --name $nsgRgName >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        state "NSG resource group is invalid. Failed NSG check." 1
    fi
    knoxNSG=$(az network nsg show -g $nsgRgName -n $knoxNSGName 2>/dev/null)
    if [ $? -ne 0 ]; then
        state "Cannot locate KNOX NSG \"$knoxNSGName\"." 1
    else
        state "Found KNOX NSG \"$knoxNSGName\" " 0
    fi
    defaultNSG=$(az network nsg show -g $nsgRgName -n $defaultNSGName 2>/dev/null)
    if [ $? -ne 0 ]; then
        state "Cannot locate Default NSG \"$defaultNSGName\"." 1
    else
        state "Found Default NSG \"$defaultNSGName\" " 0
    fi
fi


# - Firewall check: firewall check will be in a separate script. So that it can be invoked in a VM in the customer's subnet. But here we can still do some validation.
#   - If network resource group or VNET name is not provided, assuming CDP will create the VNET and subnets. There is no way to test the firewall rules. 
#   - If Public interface is not allowed, firewall must allow the destination https://docs.cloudera.com/cdp-public-cloud/cloud/requirements-azure/topics/mc-outbound_access_requirements.html
#     - this check can only be run in customer's VNET environment.
#   - else If network resource group or VNET name is not provided, 

