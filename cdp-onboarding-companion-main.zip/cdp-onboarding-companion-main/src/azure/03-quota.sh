#!/bin/bash

# importing functions from utils/common.sh
source $(cd $(dirname $0); pwd -L)/../../src/utils/common.sh

print_header "Azure quota validation"

print_banner

# 1. First need to check that is the current limit
# 2. Check what the limit is
# 3. Make a math calculation to see if Limit - Current Value is greater than 16
# 4. IF it is greater than 18, then we can move forward because we have enough available CPUs for Light Duty
#     a. IF it is less than 18, we can't move forward. 
#     b. Add to notEnoughQuota array.
#     c. We would then need to increase the limit.
# 6. Since it is greater than 18, we can now proceed to mark this precheck as green.
# 7. Add it to the enoughQuota array.
# 8. Move with next resource.
#
declare enoughQuota=()
declare notEnoughQuota=()

function print_quota() { 
    for resourceProvider in ${enoughQuota[@]}
    do
        state "$resourceProvider has enough quota in your subscription." 0
    done
}

function print_no_quota() { 
    for resourceProvider in ${notEnoughQuota[@]}
    do
        state "$resourceProvider does not have sufficient quota in your subscription." 1
    done
}

function no_quota_inf() {
    log "Used vCPUs value is: $1. You don't have enough vCPUs for deployment." 
    log "The amount needed is: $2"
    state "The amount of available vCPUs is: $3" 1
}

function quota_inf() {
    log "Used vCPUs value is: $1. You have enough vCPUs for deployment." 
    log "The amount needed is: $2"
    log "The amount left after deploying CDP should be: $(($3-$2))"
    state "The amount of available vCPUs is: $3" 0
}

region=$(cat ../../config/az_config.json | jq .required.region | tr -d '"' )
# CDPDeploymentType=$(cat ../../config/az_config.json | jq .resourceQuota.CDPDeploymentType)

# echo "I am getting here"
vmQuotaUsageResp=$(az vm list-usage --location "$region" > ./out/vm-usage.json 2>/dev/null)
if [ $? -ne 0 ]; then 
    state "Invalid response from az vm list-usage. Please try again or verify that the command is using proper syntax."
    exit 2
fi

# echo "Am I getting here??"

vmUsageCurrentVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="Total Regional vCPUs")' | jq .currentValue | tr -d '"')
vmUsageLimitVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="Total Regional vCPUs")' | jq .limit | tr -d '"')
availablevCPUs=$(($vmUsageLimitVal-$vmUsageCurrentVal))
vCPUsNeeded=18

# it's 8 vCPUs for FreeIPA nodes - 2 nodes of 2 vCPUs each.
# it's 8 vCPUs for Datalake nodes
# it's 2 vCPUs for IdBroker node
log "Checking Microsoft.Compute for available vCPUs in region..."
print_banner
if [ $availablevCPUs -lt $vCPUsNeeded ];
    then
        no_quota_inf $vmUsageCurrentVal $vCPUsNeeded $availablevCPUs
        notEnoughQuota+=("Microsoft.Compute-vCPUs")
    else
        quota_inf $vmUsageCurrentVal $vCPUsNeeded $availablevCPUs
        enoughQuota+=("Microsoft.Compute-vCPUs")
fi
print_banner

# CDP light duty will create 5 VMs, so it will need 5 disks that are standard ssd LRS.
vmDiskUsageCurrentVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="StandardSSDStorageDisks")' | jq .currentValue | tr -d '"')
vmDiskUsageLimitVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="StandardSSDStorageDisks")' | jq .limit | tr -d '"')
availableDisks=$(($vmDiskUsageLimitVal-$vmDiskUsageCurrentVal))
disksNeeded=5

log "Checking Microsoft.Compute for available disks in region..."
print_banner
if [ $availableDisks -lt $disksNeeded ];
    then
        no_quota_inf $vmDiskUsageCurrentVal $disksNeeded $availableDisks
        notEnoughQuota+=("Microsoft.Compute-Disks")
    else
        quota_inf $vmDiskUsageCurrentVal $disksNeeded $availableDisks
        enoughQuota+=("Microsoft.Compute-Disks")
fi
print_banner

# CDP light duty will create 2 availability sets for VMs.
availabilitySetsUsageCurrentVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="Availability Sets")' | jq .currentValue | tr -d '"')
availabilitySetsUsageLimitVal=$(cat ./out/vm-usage.json | jq '.[] | select(.localName=="Availability Sets")' | jq .limit | tr -d '"')
availableAvailabilitySets=$(($availabilitySetsUsageLimitVal-$availabilitySetsUsageCurrentVal))
availabilitySetsNeeded=2

log "Checking Microsoft.Compute for available availability sets in region..."
print_banner
if [ $availableAvailabilitySets -lt $availabilitySetsNeeded ];
    then
        no_quota_inf $availabilitySetsUsageCurrentVal $availabilitySetsNeeded $availableAvailabilitySets
        notEnoughQuota+=("Microsoft.Compute-AvailabilitySets")
    else
        quota_inf $availabilitySetsUsageCurrentVal $availabilitySetsNeeded $availableAvailabilitySets
        enoughQuota+=("Microsoft.Compute-AvailabilitySets")
fi
print_banner

rm -rf ./out/vm-usage.json

# Get the vnet limits and current usage values.
vnetQuotaUsageResp=$(az network list-usages --location $region > ./out/vnet-usage.json 2>/dev/null)
if [ $? -ne 0 ]; then 
    state "Invalid response from az network list-usages. Please try again or verify that the command is using proper syntax."
    exit 2
fi

# CDP will use 1 vnet for deploying CDP PC. It will deploy 40 subnets inside the vnet if specified as private or public. 
vnetUsageCurrentVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Virtual Networks")' | jq .currentValue | tr -d '"')
vnetUsageLimitVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Virtual Networks")' | jq .limit | tr -d '"')
availableVnets=$(($vnetUsageLimitVal-$vnetUsageCurrentVal))
vNetsNeeded=1

log "Checking Microsoft.Network for available VNETs in region..."
print_banner
if [ $availableVnets -lt $vNetsNeeded ];
    then
        no_quota_inf $vnetUsageCurrentVal $vNetsNeeded $availableVnets
        notEnoughQuota+=("Microsoft.Network-Vnet")
    else
        quota_inf $vnetUsageCurrentVal $vNetsNeeded $availableVnets
        enoughQuota+=("Microsoft.Network-Vnet")
fi
print_banner

# CDP will use 5 public ips for deploying CDP PC vm nodes. 
publicIPUsageCurrentVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Public IP Addresses")' | jq .currentValue | tr -d '"')
publicIPUsageLimitVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Public IP Addresses")' | jq .limit | tr -d '"')
availablePublicIP=$(($publicIPUsageLimitVal-$publicIPUsageCurrentVal))
publicIPsNeeded=5

log "Checking Microsoft.Network for available public ips in region..."
print_banner
if [ $availablePublicIP -lt $publicIPsNeeded ];
    then
        no_quota_inf $publicIPUsageCurrentVal $publicIPsNeeded $availablePublicIP
        notEnoughQuota+=("Microsoft.Network-PublicIPs")
    else
        quota_inf $publicIPUsageCurrentVal $publicIPsNeeded $availablePublicIP
        enoughQuota+=("Microsoft.Network-PublicIPs")
fi
print_banner

# CDP will use 4 network interfaces for deploying CDP PC vm nodes. 
networkInterfacesUsageCurrentVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Network Interfaces")' | jq .currentValue | tr -d '"')
networkInterfacesUsageLimitVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Network Interfaces")' | jq .limit | tr -d '"')
availableNetworkInterfaces=$(($networkInterfacesUsageLimitVal-$networkInterfacesUsageCurrentVal))
networkInterfacesNeeded=5

log "Checking Microsoft.Network for available network interfaces in region..."
print_banner
if [ $availableNetworkInterfaces -lt $networkInterfacesNeeded ];
    then
        no_quota_inf $networkInterfacesUsageCurrentVal $networkInterfacesNeeded $availableNetworkInterfaces
        notEnoughQuota+=("Microsoft.Network-NetworkInterfaces")
    else
        quota_inf $networkInterfacesUsageCurrentVal $networkInterfacesNeeded $availableNetworkInterfaces
        enoughQuota+=("Microsoft.Network-NetworkInterfaces")
fi
print_banner

# CDP will use 3 network security groups for deploying CDP PC vm nodes. 
nsgUsageCurrentVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Network Security Groups")' | jq .currentValue | tr -d '"')
nsgUsageLimitVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Network Security Groups")' | jq .limit | tr -d '"')
availableNSGs=$(($nsgUsageLimitVal-$nsgUsageCurrentVal))
nsgNeeded=3

log "Checking Microsoft.Network for available network security groups in region..."
print_banner
if [ $availableNSGs -lt $nsgNeeded ];
    then
        no_quota_inf $nsgUsageCurrentVal $nsgNeeded $availableNSGs
        notEnoughQuota+=("Microsoft.Network-NSG")
    else
        quota_inf $nsgUsageCurrentVal $nsgNeeded $availableNSGs
        enoughQuota+=("Microsoft.Network-NSG")
fi
print_banner

# CDP will use 1 load balancer in light duty.
loadBalancerUsageCurrentVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Load Balancers")' | jq .currentValue | tr -d '"')
loadBalancerUsageLimitVal=$(cat ./out/vnet-usage.json | jq '.[] | select(.name.localizedValue=="Load Balancers")' | jq .limit | tr -d '"')
availableLoadBalancers=$(($loadBalancerUsageLimitVal-$loadBalancerUsageCurrentVal))
loadBalancersNeeded=1

log "Checking Microsoft.Network for load balancers security groups in region..."
print_banner
if [ $availableLoadBalancers -lt $loadBalancersNeeded ];
    then
        no_quota_inf $loadBalancerUsageCurrentVal $loadBalancersNeeded $availableLoadBalancers
        notEnoughQuota+=("Microsoft.Network-LoadBalancer")
    else
        quota_inf $loadBalancerUsageCurrentVal $loadBalancersNeeded $availableLoadBalancers
        enoughQuota+=("Microsoft.Network-LoadBalancer")
fi
print_banner

rm -rf ./out/vnet-usage.json

# Get the storage account limits and current usage values.
storageAccQuotaUsageResp=$(az storage account show-usage --location $region > ./out/storage-acc-usage.json 2>/dev/null)
if [ $? -ne 0 ]; then 
    state "Invalid response from az storage account show-usage. Please try again or verify that the command is using proper syntax."
    exit 2
fi

# CDP will use 2 storage accounts for deploying CDP PC. It will deploy 1 for datalake and 1 for hosting os disk images.
storageAccUsageCurrentVal=$(cat ./out/storage-acc-usage.json | jq .currentValue | tr -d '"')
storageAccUsageLimitVal=$(cat ./out/storage-acc-usage.json |  jq .limit | tr -d '"')
availableStorageAcc=$(($storageAccUsageLimitVal-$storageAccUsageCurrentVal))
storageAccsNeeded=2

log "Checking Microsoft.Storage for available storage accounts in region..."
print_banner
if [ $availableStorageAcc -lt $storageAccsNeeded ];
    then
        no_quota_inf $storageAccUsageCurrentVal $storageAccsNeeded $availableStorageAcc
        notEnoughQuota+=("Microsoft.Storage-StorageAccounts")
    else
        quota_inf $storageAccUsageCurrentVal $storageAccsNeeded $availableStorageAcc
        enoughQuota+=("Microsoft.Storage-StorageAccounts")
fi
print_banner

rm -rf ./out/storage-acc-usage.json

if [ "${#notEnoughQuota[@]}" -eq 0 ]; 
    then
        print_quota
        print_banner
        log "All required resources have enough quota."
    else
        print_quota
        print_no_quota
        log "Please check the log file to check which resources don't have enough quota."
        log "To request more quota, please visit: https://learn.microsoft.com/en-us/azure/quotas/quickstart-increase-quota-portal#request-a-quota-increase"
fi
print_banner
