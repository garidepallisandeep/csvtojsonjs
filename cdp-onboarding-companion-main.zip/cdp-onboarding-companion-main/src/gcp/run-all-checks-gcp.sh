#!/bin/bash

declare -f gcp_admin_access

function state() {
    local msg=$1
    local flag=$2
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[0;33m'
    NC='\033[0m' # No Color

    if [ "$flag" == 0 ]; then
        echo -e "${GREEN} PASS ${NC} $msg"
    elif [ "$flag" == 2 ]; then
        echo -e "${YELLOW} WARN ${NC} $msg"
    else
        echo -e "${RED} FAIL ${NC} $msg"
    fi 

}

function print_label() {
    printf "%-${SYSINFO_TITLE_WIDTH}s %s\n" "$1:" "$2"
}

function print_time() {
    print_label "Date & Time " "$(date)"
}

function print_banner() {
    echo "-------------------------------------"
}

function print_header() {
    local msg=$1
    echo "$1"
}

function print_fqdn() {
    print_label "FQDN" "$(hostname -f)"
}

function validate_admin() {
    source iam-validate-gcp.sh
    gcp_admin_access=$(check_admin_permission)  
}

function validate_apis() {
    enable_apis
}

function validate_sa_permissions() {
    source iam-validate-gcp.sh
    check_sa_permissions
}
function validate_quotas() {
    source quotas-validate-gcp.sh
    check_quotas
}

print_header "GCP Prerequisites validation (for onboarding to CDP:)"
print_banner
print_time
print_label "Checks ran from host" "$(print_fqdn)"
print_banner

###########################################################
### Printing sample output here. Actual logic to be built
###########################################################
validate_admin
state "CDP admin access validation" $gcp_admin_access
#validate_apis
state "Enabling Google API's" 0
#validate_sa_permissions
state "CDP service account permissions" $perms_exist
validate_quotas
#state "Validating Quotas" 0
#state "API's validation"


print_banner
print_header "ADDITIONAL INFO:"

#echo "IAM: Missing AWS permissions: IDBROKER_ROLE doesn't have sts:AssumeRole permission on *"
#echo "Limits: Internet gateways per Region - should be increased to 20"
#echo "Network: CCM endpoint is not accessible. Work with firewall team"

