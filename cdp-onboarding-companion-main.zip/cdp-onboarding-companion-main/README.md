# CDP Onboarding Companion

**NOTE:** As of May 2023, this tool is a work in progress & under development. AWS checks are the most complete, followed by GCP. Please exercise caution & take this with a grain of salt

- The goal of this project is to make prerequisite validation a very simple experience for customers & SAs
- **Assumptions & Prerequisites**
- - Any tools used within this script should be portable & must work in any environment
- - This project has been developed & fully testes on CentOS, but could run on any Linux machine.
- - Should be run from a machine that has access to AWS CLI & CDP CLI, and supports bash
- - There are 2 main different checks blocks we should understand & choose from where execute them:
    - Permissions, IAMs, Quotas... Could be tested from a local terminal because they use the CSP CLI.
    - Networking tests: It should be run within the subnet/s we want to deploy Cloudera Data Platform.
- - In resume, we recommend to run all the project from a [CentOS Micro-Instance](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/option3-task1-launch-ec2-instance.html) within the VPC/Vnet for CDP.

**As a guide, the tools use the following components**
  - [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html)
    - Install and configure the AWS CLI & login/profile. It could be a local IAM user or use SSO, but requires PowerUser role privileges.
      ```sh
        curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
        unzip awscliv2.zip
        sudo ./aws/install
      ```
  - Recommended AWS SSM Agent for web console
   In case you want to run the project from a EC2 micro-instance, [you could use SSM Console to connect to the VM](https://dev.to/aws-builders/how-to-set-up-session-manager-and-enable-ssh-over-ssm-43k9).
    ```sh
    sudo yum install -y https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent/latest/linux_amd64/amazon-ssm-agent.rpm && sudo systemctl enable amazon-ssm-agent && sudo systemctl start amazon-ssm-agent
    ```
  - Bash
  - Netcap Tool
    ```sh 
    sudo yum -y install nc
    ```
  - Python 3 with venv and Pandas
    ```sh
    # install python 3.10
    sudo yum update -y
    sudo yum groupinstall "Development Tools" -y
    sudo yum install openssl-devel libffi-devel bzip2-devel wget nc -y
    sudo wget https://www.python.org/ftp/python/3.10.2/Python-3.10.2.tgz
    sudo tar xzf Python-3.10.2.tgz && cd Python-3.10.2
    sudo ./configure --enable-optimizations
    nproc && make -j $(nproc)
    sudo make altinstall
    python3.10 --version
    sudo yum install python3-pip

    # create virtual environment
    sudo pip install virtualenv
    sudo virtualenv venv
    sudo source venv/bin/activate
    sudo python -m pip install pandas
    ```
   - [CDP CLI](https://docs.cloudera.com/cdp-public-cloud/cloud/cli/topics/mc-cli-client-setup.html)
      - Install and configure the CLI & Login
          ```sh
            python3 -m pip install cdpcli 
          ```

  - Ensure all the parameters are updated in config file based on your CSP (aws_config.json, az_config.json, gcp-config.json)

  - Select one of the below config template depending on your CDP env size and update your cloud account region, roles, storage, policies & quota limits
      1) aws_config_ld_full.json - DL+DS(CDW,CML,DFX,CML,COD)+ DH(Stream messaging)
      2) aws_config_ld_minimal.json -  DL+ DH(DE,Real time Data mart)
      3) aws_config_md_full.json - DL+DS(CDW,CML,DFX,CML,COD)+ DH(Stream messaging)
      4) aws_config_md_minimal.json	- DL+ DH(DE,Real time Data mart)


 **Sample launch command**:
```sh
./run-all-checks.sh -c aws -p config/aws_config_ld_full.json
./run-all-checks.sh -c aws -p config/aws_config_ld_minimal.json
./run-all-checks.sh -c aws -p config/aws_config_md_full.json
./run-all-checks.sh -c aws -p config/aws_config_md_minimal.json
```

**Example expected final outcomes**

![Alt text](images/expectedoutput2.png?raw=true "Title")
