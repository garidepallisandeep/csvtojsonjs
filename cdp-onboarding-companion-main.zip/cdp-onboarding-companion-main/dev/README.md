The purposes of this directory is to provide a lightweight & quick development environment for developers of the tool.
We will use Vagrant for this purpose & it is assumed that developers will have a mac laptop.

In a 

Dev environment is based on CentOS

1) Install Vagrant
```brew install hashicorp/tap/hashicorp-vagrant```
2) Make sure you have a virtualisation software installed on your laptop
   (Ex: Oracle virtualbox doesn't need a license and is available to download)

