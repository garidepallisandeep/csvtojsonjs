#!/bin/bash
#source ./src/utils/common.sh
source $(cd $(dirname $0); pwd -L)/src/utils/common.sh

EPOCHNOW=`date +%s`

#############################################################
# Function : run_aws_validations
# Description : Function to run all pre-checks for AWS.
# Input : config_file
#############################################################
function run_aws_validations()
{
  fetch_parameters_aws "$CONFIGS"

  # Validation of Config File.
  log "Running Config file Validation"
  validate_aws_config

  # Running IAM Validation
  log "Running IAM Validations"
  $(pwd -L)/src/aws/01-iam-validate.sh >> out/$LOG_FILE

#  log "Running CDP admin access validation"
#  $(pwd -L)/src/aws/04-cdp-access-validate.sh >> out/$LOG_FILE
  
  # Running AWS Quota Limit Checks.
  log "Running checks on limits"
  $(pwd -L)/src/aws/02-quota.sh >> out/$LOG_FILE

  # Running Invoking AWS Networking Tests
  log "Invoking AWS Networking Tests"
  $(pwd -L)/src/aws/03-network-validate.sh >> out/$LOG_FILE
  print_banner
}

##############################################################################
# Function : validate_aws_config
# Description : Function to validate whether all required config are provided.
##############################################################################
function validate_aws_config()
{
  [[ -z "$region" ]] && missing_conf="AWS region - required to host CDP in your AWS account"
  [[ -z "$CDPcontrolplaneregion" ]] && missing_conf="Cloudera control plane region - requires your CDP account and its data to remain within a specific geographical region"
  [[ -z "$bucket_name" ]] && missing_conf="AWS s3 bucket - required to store Data, logs and Backups"
  [[ -z "$cross_account_role" ]] && missing_conf="Cross account role - required to allow CDP to provision resources in your AWS account"
  [[ -z "$datalake_admin_role" ]] && missing_conf="datalake_admin_role - required for data, log & Audit access"
  [[ -z "$idbroker_role" ]] && missing_conf="idbroker_role - required to be assumed by ec2_instances"
  [[ -z "$log_role" ]] && missing_conf="log_role - required to access logs and backup"
  [[ -z "$ranger_audit_role" ]] && missing_conf="ranger_audit_role - required to access Audit data"
  [[ -z "$storage_base_location" ]] && missing_conf="AWS s3 base - required to store your data processed by CDP"
  [[ -z "$backup_location_base" ]] && missing_conf="AWS s3 backup - required to store CDP backups"
  [[ -z "$log_location_base" ]] && missing_conf="AWS s3 logs - required to store CDP logs"
  if [[ -n "$missing_conf" ]]; then
   echo "$missing_conf is missing in config file"
   exit 0;
  else
   log "Script Recevied All Config Inputs Continue With CDP Pre-Req Validation"
  fi
}

#############################################################
# Function : run_azure_validations
# Description : Function to run all pre-checks for Azure.
# Input : config_file
#############################################################
function run_azure_validations()
{
  fetch_parameters_azure "$CONFIGS"
  print_header "CSP Detected from configuration file: $CSP"
  print_header "Azure tool is not ready yet, coming soon..."
  # call script 1
  # call script 2
  # call script 3 - Networking Tests
  print_banner
  print_header "Invoking AZURE Networking Tests"
  log "Invoking AZURE Networking Tests"
  $(pwd -L)/src/azure/04-network-validate.sh >> out/$LOG_FILE
  # call script 4

#  state "IAM validation" 0
#  state "Quota validation" 2
#  state "Network validation" 1
#  state "CDP admin access validation" 1
}

#############################################################
# Function : run_gcp_validations
# Description : Function to run all pre-checks for GCP.
# Input : config_file
#############################################################
function run_gcp_validations()
{
  fetch_parameters_gcp "$CONFIGS"
  print_header "CSP Detected from configuration file: $CSP"
    
    echo -ne '>>>                        [20%]\r'
    . src/gcp/02-quota.sh
    state "Quota validation" $quotas_exist
    sleep 2
    echo -ne '>>>>>                      [30%]\r'
    . src/gcp/03-network-validate.sh
    state "Network validation" $cdp_network_valid
    sleep 2
     echo -ne '>>>>>>>                    [40%]\r'
    state "API validation" 0
    sleep 2
    echo -ne '>>>>>>>>>>>                [50%]\r'
    . src/gcp/04-storage-validate.sh
    state "Storage validation" $storage_validation
    sleep 2
    echo -ne '>>>>>>>>>>>>>>>>>          [70%]\r'
    . src/gcp/01-iam-validate.sh
    state "IAM validation" $perms_exist
    sleep 10
    echo -ne '>>>>>>>>>>>>>>>>>>>>>>>>>>            [100%]\r'
    state "CDP admin access validation" $check_admin_permission
    echo -ne '\n'    
}

function usage
{
    echo "usage: arg_parse_example -a AN_ARG -s SOME_MORE_ARGS [-y YET_MORE_ARGS || -h]"
    echo "   ";
    echo "  -h | --help   : Print help";
    echo "  -c | --csp    : Choose CSP";
    echo "  -p | --parameter-file    : path to config file";
}

function parse_args()
{
  # positional args
  args=()

  # named args
  while [ "$1" != "" ]; do
      case "$1" in
          -c | --csp )                  CSP="$2";             shift;;
          -p | --parameter-file )       CONFIGS="$2";             shift;;
          -h | --help )                 usage;                exit;; # quit and show usage
          * )                           args+=("$1")          # if no match, add it to the positional args
      esac
      shift # move to next kv pair
  done

  # restore positional args
  set -- "${args[@]}"

  # set positionals to vars
  positional_1="${args[0]}"
  positional_2="${args[1]}"

  # validate required args
  if [[ -z "${CSP}" || -z "${CONFIGS}" ]]; then
      echo "Invalid arguments"
      usage
      exit;
  fi

#  TODO later: set defaults
#  if [[ -z "$yet_more_args" ]]; then
#      yet_more_args="a default value";
#  fi
}

parse_args "$@"
export CSP
export LOG_FILE="runlogs-$EPOCHNOW.log"
export ERROR_FILE="out/error-$EPOCHNOW.err"
print_banner
print_title
print_banner
print_meta "Checks ran from host" "$(print_fqdn)"
print_banner

if [ "$CSP" == "aws" ]
then
  run_aws_validations
fi

if [ "$CSP" == "gcp" ]
then
  run_gcp_validations
fi

if [ "$CSP" == "azure" ]
then
  run_azure_validations
fi


# If Any of the pre-check failed, display all errors on screen.
if [ -e $ERROR_FILE ]; then
  # cat $ERROR_FILE > $(tty)
  read -p "Do you want to see the error messages (y/n)? " -n 1 -r
  echo    #  move to a new line
  if [[ $REPLY =~ ^[Yy]$ ]]
  then
    cat $ERROR_FILE > $(tty)
  fi
fi
print_banner
